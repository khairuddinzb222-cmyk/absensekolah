import {
  ShieldCheck,
  ScanFace,
  MapPin,
  Clock,
  Bell,
  UserCog,
  LayoutDashboard,
  Workflow,
  BookOpen,
  Database,
  FileText,
} from 'lucide-react';

export type NavSection = {
  id: string;
  label: string;
  icon: typeof ShieldCheck;
  group: string;
};

export const navSections: NavSection[] = [
  { id: 'overview', label: 'Overview', icon: FileText, group: 'Umum' },
  { id: 'security', label: 'Keamanan Akses & URL Separation', icon: ShieldCheck, group: 'Spesifikasi Sistem' },
  { id: 'enrollment', label: 'Pendaftaran Wajah & Validasi', icon: ScanFace, group: 'Spesifikasi Sistem' },
  { id: 'geofencing', label: 'Absensi & Geofencing 300m', icon: MapPin, group: 'Spesifikasi Sistem' },
  { id: 'schedule', label: 'Manajemen Waktu & Toleransi', icon: Clock, group: 'Spesifikasi Sistem' },
  { id: 'integration', label: 'Integrasi & Notifikasi', icon: Bell, group: 'Spesifikasi Sistem' },
  { id: 'self-service', label: 'Portal Mandiri Guru', icon: UserCog, group: 'Spesifikasi Sistem' },
  { id: 'admin-panel', label: 'Dashboard & Panel Admin', icon: LayoutDashboard, group: 'Spesifikasi Sistem' },
  { id: 'workflow', label: 'Alur Kerja & SOP', icon: Workflow, group: 'Spesifikasi Sistem' },
  { id: 'manual-teacher', label: 'Panduan Guru', icon: BookOpen, group: 'Buku Panduan' },
  { id: 'manual-admin', label: 'Panduan Admin', icon: BookOpen, group: 'Buku Panduan' },
  { id: 'tech-appendix', label: 'Lampiran Teknis', icon: Database, group: 'Lampiran' },
];

export const schoolInfo = {
  name: 'SMP Kartika XIV-1 Banda Aceh',
  address: 'Jl. Nyak Adam Kamil II, Peuniti, Kec. Baiturrahman, Kota Banda Aceh',
  portalGuruUrl: 'https://smpkartika14-1.sch.id',
  portalAdminUrl: 'https://admin.smpkartika14-1.sch.id',
  lat: '5.5483° LS',
  lng: '95.3237° BT',
  radius: '300 meter',
};
