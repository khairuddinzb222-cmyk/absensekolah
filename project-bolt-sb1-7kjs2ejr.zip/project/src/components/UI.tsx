import { ReactNode } from 'react';
import { CheckCircle2, XCircle, AlertTriangle, Info } from 'lucide-react';

type CardProps = {
  icon?: ReactNode;
  title: string;
  children: ReactNode;
  className?: string;
};

export function Card({ icon, title, children, className = '' }: CardProps) {
  return (
    <div className={`bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow ${className}`}>
      <div className="p-5">
        {icon && (
          <div className="w-10 h-10 rounded-lg bg-sky-50 flex items-center justify-center mb-3 text-sky-600">
            {icon}
          </div>
        )}
        <h3 className="font-semibold text-slate-800 mb-2">{title}</h3>
        <div className="text-sm text-slate-600 leading-relaxed">{children}</div>
      </div>
    </div>
  );
}

type BadgeProps = {
  children: ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info';
};

export function Badge({ children, variant = 'default' }: BadgeProps) {
  const styles: Record<string, string> = {
    default: 'bg-slate-100 text-slate-600 border-slate-200',
    success: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    warning: 'bg-amber-50 text-amber-700 border-amber-200',
    danger: 'bg-rose-50 text-rose-700 border-rose-200',
    info: 'bg-sky-50 text-sky-700 border-sky-200',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium border ${styles[variant]}`}>
      {children}
    </span>
  );
}

type CalloutProps = {
  type?: 'success' | 'warning' | 'danger' | 'info';
  title?: string;
  children: ReactNode;
};

export function Callout({ type = 'info', title, children }: CalloutProps) {
  const config = {
    success: { icon: CheckCircle2, bg: 'bg-emerald-50 border-emerald-200', text: 'text-emerald-800', iconColor: 'text-emerald-500' },
    warning: { icon: AlertTriangle, bg: 'bg-amber-50 border-amber-200', text: 'text-amber-800', iconColor: 'text-amber-500' },
    danger: { icon: XCircle, bg: 'bg-rose-50 border-rose-200', text: 'text-rose-800', iconColor: 'text-rose-500' },
    info: { icon: Info, bg: 'bg-sky-50 border-sky-200', text: 'text-sky-800', iconColor: 'text-sky-500' },
  };
  const c = config[type];
  const Icon = c.icon;
  return (
    <div className={`flex gap-3 p-4 rounded-lg border ${c.bg} my-4`}>
      <Icon className={`w-5 h-5 shrink-0 mt-0.5 ${c.iconColor}`} />
      <div>
        {title && <p className={`font-semibold ${c.text} mb-1`}>{title}</p>}
        <div className={`text-sm ${c.text} leading-relaxed`}>{children}</div>
      </div>
    </div>
  );
}

type TableProps = {
  headers: string[];
  rows: ReactNode[][];
};

export function Table({ headers, rows }: TableProps) {
  return (
    <div className="overflow-x-auto my-4 rounded-lg border border-slate-200">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-slate-50 border-b border-slate-200">
            {headers.map((h, i) => (
              <th key={i} className="text-left px-4 py-3 font-semibold text-slate-700 whitespace-nowrap">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((row, i) => (
            <tr key={i} className="hover:bg-slate-50/50 transition-colors">
              {row.map((cell, j) => (
                <td key={j} className="px-4 py-3 text-slate-600 align-top">
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

type StepProps = {
  step: number | string;
  title: string;
  children: ReactNode;
};

export function Step({ step, title, children }: StepProps) {
  return (
    <div className="flex gap-4">
      <div className="flex flex-col items-center">
        <div className="w-8 h-8 rounded-full bg-sky-600 text-white flex items-center justify-center text-sm font-bold shrink-0">
          {step}
        </div>
        <div className="w-px flex-1 bg-slate-200 mt-2" />
      </div>
      <div className="pb-6 flex-1">
        <h4 className="font-semibold text-slate-800 mb-1">{title}</h4>
        <div className="text-sm text-slate-600 leading-relaxed">{children}</div>
      </div>
    </div>
  );
}
