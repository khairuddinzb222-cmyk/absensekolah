import { navSections, schoolInfo } from '@/data/specData';
import {
  Menu,
  X,
  ChevronRight,
  School,
} from 'lucide-react';

type Props = {
  activeId: string;
  onNavigate: (id: string) => void;
  mobileOpen: boolean;
  setMobileOpen: (v: boolean) => void;
};

export default function Sidebar({ activeId, onNavigate, mobileOpen, setMobileOpen }: Props) {
  const groups: { name: string; items: typeof navSections }[] = [];
  navSections.forEach((s) => {
    let g = groups.find((x) => x.name === s.group);
    if (!g) {
      g = { name: s.group, items: [] };
      groups.push(g);
    }
    g.items.push(s);
  });

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-30 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}
      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-72 bg-slate-900 text-slate-300 z-40 transform transition-transform duration-300 overflow-y-auto ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center justify-between px-5 py-5 border-b border-slate-700/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-sky-500 to-cyan-400 flex items-center justify-center shrink-0">
              <School className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white leading-tight">Sistem Absensi</p>
              <p className="text-[11px] text-slate-400 leading-tight">Face Recognition</p>
            </div>
          </div>
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="px-3 py-4 space-y-5">
          {groups.map((group) => (
            <div key={group.name}>
              <p className="px-3 mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                {group.name}
              </p>
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const active = activeId === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onNavigate(item.id)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all ${
                        active
                          ? 'bg-sky-500/15 text-sky-300 font-medium'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-sky-400' : ''}`} />
                      <span className="text-left leading-tight">{item.label}</span>
                      {active && <ChevronRight className="w-3.5 h-3.5 ml-auto text-sky-400" />}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="px-5 py-4 mt-2 border-t border-slate-700/60">
          <p className="text-[11px] text-slate-500 leading-relaxed">
            {schoolInfo.name}
            <br />
            {schoolInfo.address}
          </p>
        </div>
      </aside>
    </>
  );
}
