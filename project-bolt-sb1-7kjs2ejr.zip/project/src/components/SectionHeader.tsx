import { ReactNode } from 'react';

type Props = {
  number?: string;
  title: string;
  subtitle?: string;
  children?: ReactNode;
};

export default function SectionHeader({ number, title, subtitle, children }: Props) {
  return (
    <div className="mb-8">
      {number && (
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-50 text-sky-700 text-xs font-semibold mb-3 border border-sky-100">
          {number}
        </div>
      )}
      <h2 className="text-2xl md:text-3xl font-bold text-slate-800 tracking-tight">{title}</h2>
      {subtitle && <p className="mt-2 text-slate-500 text-base max-w-3xl">{subtitle}</p>}
      {children}
    </div>
  );
}
