import { useState, useEffect, useCallback } from 'react';
import Sidebar from '@/components/Sidebar';
import OverviewSection from '@/sections/OverviewSection';
import SecuritySection from '@/sections/SecuritySection';
import EnrollmentSection from '@/sections/EnrollmentSection';
import GeofencingSection from '@/sections/GeofencingSection';
import ScheduleSection from '@/sections/ScheduleSection';
import IntegrationSection from '@/sections/IntegrationSection';
import SelfServiceSection from '@/sections/SelfServiceSection';
import AdminPanelSection from '@/sections/AdminPanelSection';
import WorkflowSection from '@/sections/WorkflowSection';
import ManualTeacherSection from '@/sections/ManualTeacherSection';
import ManualAdminSection from '@/sections/ManualAdminSection';
import TechAppendixSection from '@/sections/TechAppendixSection';
import { navSections } from '@/data/specData';
import { Menu, ChevronUp } from 'lucide-react';

export default function App() {
  const [activeId, setActiveId] = useState('overview');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showTop, setShowTop] = useState(false);

  const handleNavigate = useCallback((id: string) => {
    setActiveId(id);
    setMobileOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  useEffect(() => {
    const onScroll = () => {
      const sections = navSections.map((s) => s.id);
      const scrollPos = window.scrollY + 120;
      let current = sections[0];
      for (const id of sections) {
        const el = document.getElementById(id);
        if (el && el.offsetTop <= scrollPos) {
          current = id;
        }
      }
      setActiveId(current);
      setShowTop(window.scrollY > 600);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const renderSection = () => {
    switch (activeId) {
      case 'overview': return <OverviewSection />;
      case 'security': return <SecuritySection />;
      case 'enrollment': return <EnrollmentSection />;
      case 'geofencing': return <GeofencingSection />;
      case 'schedule': return <ScheduleSection />;
      case 'integration': return <IntegrationSection />;
      case 'self-service': return <SelfServiceSection />;
      case 'admin-panel': return <AdminPanelSection />;
      case 'workflow': return <WorkflowSection />;
      case 'manual-teacher': return <ManualTeacherSection />;
      case 'manual-admin': return <ManualAdminSection />;
      case 'tech-appendix': return <TechAppendixSection />;
      default: return <OverviewSection />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar
        activeId={activeId}
        onNavigate={handleNavigate}
        mobileOpen={mobileOpen}
        setMobileOpen={setMobileOpen}
      />

      <div className="flex-1 min-w-0">
        {/* Mobile top bar */}
        <div className="lg:hidden sticky top-0 z-20 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => setMobileOpen(true)}
            className="flex items-center gap-2 text-slate-700"
          >
            <Menu className="w-5 h-5" />
            <span className="text-sm font-medium">Navigasi</span>
          </button>
          <span className="text-xs text-slate-500">Sistem Absensi Wajah</span>
        </div>

        <main className="max-w-5xl mx-auto px-5 md:px-10 py-8 md:py-12">
          <div id={activeId} key={activeId} className="scroll-mt-20">
            {renderSection()}
          </div>
        </main>

        {/* Back to top */}
        {showTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-6 right-6 w-11 h-11 rounded-full bg-slate-800 text-white shadow-lg flex items-center justify-center hover:bg-slate-700 transition-colors z-20"
            aria-label="Kembali ke atas"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
        )}

        <footer className="border-t border-slate-200 mt-12 py-6 px-5 md:px-10">
          <p className="text-center text-xs text-slate-400">
            Dokumen Spesifikasi Sistem Absensi Harian Guru Berbasis Scan Wajah &middot; SMP Kartika XIV-1 Banda Aceh &middot; v1.0
          </p>
        </footer>
      </div>
    </div>
  );
}
