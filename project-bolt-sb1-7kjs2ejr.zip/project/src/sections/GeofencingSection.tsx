import SectionHeader from '@/components/SectionHeader';
import { Card, Badge, Table, Callout } from '@/components/UI';
import { schoolInfo } from '@/data/specData';
import { MapPin, ShieldAlert, Zap, WifiOff, Smartphone, Lock, Radio } from 'lucide-react';

export default function GeofencingSection() {
  return (
    <div>
      <SectionHeader
        number="Modul 3"
        title="Absensi & Geofencing 300 Meter"
        subtitle="Kunci koordinat sekolah, deteksi multi-source, anti-mock location, liveness detection, kecepatan di bawah 2 detik, dan mode offline."
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">3.1 Absen Berbasis Lokasi (Radius 300 Meter)</h3>
      <Callout type="info" title={`Target Lokasi: ${schoolInfo.name}`}>
        {schoolInfo.address}<br />
        Latitude: {schoolInfo.lat} &middot; Longitude: {schoolInfo.lng} &middot; Radius: <Badge variant="info">{schoolInfo.radius}</Badge>
      </Callout>
      <Card icon={<MapPin className="w-5 h-5" />} title="Mekanisme Penguncian" className="mb-4">
        <ol className="list-decimal pl-4 space-y-1">
          <li>Guru buka halaman absensi, perangkat mengambil koordinat GPS/Wi-Fi saat ini.</li>
          <li>Sistem menghitung jarak (Haversine) antara posisi guru dan koordinat sekolah.</li>
          <li>Jika jarak ≤ 300 m → tombol "Scan Wajah" aktif.</li>
          <li>Jika jarak lebih dari 300 m → tombol "Scan Wajah" <strong>terkunci otomatis</strong> + pesan jarak.</li>
          <li>Sistem menampilkan peta mini (Google Maps) dengan marker sekolah, lingkaran radius, dan posisi guru.</li>
        </ol>
      </Card>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">3.2 Teknologi Pendeteksi Lokasi & Anti-Kecurangan</h3>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card icon={<Radio className="w-5 h-5" />} title="Multi-Source Location (Akurasi Tinggi)">
          <ul className="list-disc pl-4 space-y-1">
            <li><strong>GPS</strong> (satelit) - akurasi 3-5 meter di luar ruangan.</li>
            <li><strong>GLONASS</strong> - tambahan akurasi di area padat.</li>
            <li><strong>Wi-Fi Positioning</strong> - triangulasi Wi-Fi, akurasi 10-20 meter di dalam ruangan.</li>
            <li><strong>Cell Tower Triangulation</strong> - fallback, akurasi 50-500 meter.</li>
            <li>Perangkat wajib "Mode Akurasi Tinggi" (High Accuracy).</li>
          </ul>
        </Card>
        <Card icon={<ShieldAlert className="w-5 h-5" />} title="Anti-Mock Location (7 Lapisan Deteksi)">
          <ul className="list-decimal pl-4 space-y-1">
            <li>API Browser: <code className="text-xs bg-slate-100 px-1 rounded">enableHighAccuracy: true</code>. Akurasi lebih dari 100m = mencurigakan.</li>
            <li>Flag Mock: deteksi <code className="text-xs bg-slate-100 px-1 rounded">isFromMockProvider</code>.</li>
            <li>Developer Options: deteksi USB Debugging aktif.</li>
            <li>Konsistensi Sensor: cross-check GPS vs Wi-Fi vs IP geolocation.</li>
            <li>Timestamp & Movement: deteksi lonjakan koordinat tidak realistis.</li>
            <li>Altitude Check: cross-check altitude dengan topografi Banda Aceh.</li>
            <li>Native App Wrapper: plugin native untuk akses flag mock lebih dalam.</li>
          </ul>
        </Card>
      </div>
      <Callout type="danger" title="Tindakan Saat Terdeteksi Manipulasi">
        <ul className="list-disc pl-4 space-y-1">
          <li>Absensi <strong>ditolak otomatis</strong>.</li>
          <li>Log keamanan tercatat (guru siapa, waktu, jenis manipulasi).</li>
          <li>Notifikasi otomatis ke admin dan Kepala Sekolah.</li>
          <li>Guru melihat pesan: "Sistem mendeteksi potensi manipulasi lokasi. Absensi ditolak. Silakan hubungi Admin TU."</li>
          <li>Jika berulang 3x → akun dikunci sementara, wajib klarifikasi Kepsek.</li>
        </ul>
      </Callout>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">3.3 Deteksi Keaslian Wajah (Liveness Detection)</h3>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card icon={<Smartphone className="w-5 h-5" />} title="Active Liveness (Challenge-Response)">
          <ul className="list-disc pl-4 space-y-1">
            <li>Instruksi acak: "Kedipkan mata 2 kali", "Tersenyum", "Putar wajah ke kiri", "Buka mulut".</li>
            <li>Wajib dilakukan dalam 5 detik.</li>
          </ul>
        </Card>
        <Card title="Passive Liveness (Texture Analysis)">
          <ul className="list-disc pl-4 space-y-1">
            <li>Analisis tekstur: foto cetak memiliki pola moire/refleksi kertas berbeda dari kulit hidup.</li>
            <li>Model CNN terlatih membedakan live vs spoof.</li>
            <li>Micro-movement analysis: deteksi nafas, kedip spontan, pergerakan pupil.</li>
          </ul>
        </Card>
      </div>
      <p className="text-sm text-slate-600 mb-4">
        <strong>Threshold:</strong> Skor liveness ≥ 0.85 (dapat dikalibrasi admin). Di bawah threshold → absensi ditolak dengan
        pesan "Verifikasi keaslian wajah gagal. Pastikan Anda tidak menggunakan foto/video."
      </p>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">3.4 Kecepatan Pemindaian</h3>
      <div className="grid md:grid-cols-4 gap-4 mb-4">
        <div className="bg-slate-800 rounded-xl p-4 text-white text-center">
          <Zap className="w-6 h-6 mx-auto mb-2 text-amber-400" />
          <p className="text-2xl font-bold">&lt; 2</p>
          <p className="text-xs text-slate-400">detik end-to-end</p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-slate-200 text-center">
          <p className="text-2xl font-bold text-slate-800">&lt; 500ms</p>
          <p className="text-xs text-slate-500">capture frame</p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-slate-200 text-center">
          <p className="text-2xl font-bold text-slate-800">&lt; 800ms</p>
          <p className="text-xs text-slate-500">generate embedding</p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-slate-200 text-center">
          <p className="text-2xl font-bold text-slate-800">&lt; 500ms</p>
          <p className="text-xs text-slate-500">match (1:1)</p>
        </div>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">3.5 Mode Offline Sementara</h3>
      <Card icon={<WifiOff className="w-5 h-5" />} title="Mekanisme Offline + Sync" className="mb-4">
        <ol className="list-decimal pl-4 space-y-1">
          <li>Saat scan berhasil tapi koneksi server gagal → data absensi (timestamp, koordinat, embedding match result, foto bukti) disimpan di IndexedDB/localStorage perangkat.</li>
          <li>Data offline ditandai status "Pending Sync".</li>
          <li>Background service worker memantau koneksi; saat online, data di-sync secara berurutan (FIFO).</li>
          <li>Server melakukan idempotency check (hash timestamp + user_id) untuk mencegah duplikasi.</li>
          <li>Setelah sync berhasil, data lokal ditandai "Synced" dan dapat dihapus setelah 7 hari.</li>
          <li>Guru melihat badge: "Tersimpan offline - menunggu sinkronisasi".</li>
        </ol>
      </Card>
      <Callout type="warning" title="Batasan Mode Offline">
        <ul className="list-disc pl-4 space-y-1">
          <li>Hanya untuk menyimpan hasil scan yang <strong>sudah lolos verifikasi lokal</strong> (lokasi + liveness). Tidak boleh digunakan untuk melewati geofence.</li>
          <li>Maksimal 5 absensi offline tersimpan per perangkat (anti penimbunan).</li>
          <li>Data offline terenkripsi (AES) di perangkat.</li>
        </ul>
      </Callout>
    </div>
  );
}
