import SectionHeader from '@/components/SectionHeader';
import { Card, Badge, Table, Callout } from '@/components/UI';
import { Clock, Calendar, Map, Users } from 'lucide-react';

export default function ScheduleSection() {
  return (
    <div>
      <SectionHeader
        number="Modul 4"
        title="Manajemen Waktu & Toleransi"
        subtitle="Kustomisasi jam masuk/pulang Senin-Sabtu, toleransi keterlambatan dinamis, pengaturan koordinat sekolah, dan jadwal shifting."
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">4.1 Kustomisasi Jam Masuk & Pulang Harian (Senin-Sabtu)</h3>
      <p className="text-slate-600 mb-4">Admin dapat mengedit secara manual jadwal jam masuk dan jam pulang yang berbeda untuk setiap hari.</p>
      <Table
        headers={['Hari', 'Jam Masuk', 'Toleransi', 'Jam Pulang', 'Keterangan']}
        rows={[
          ['Senin', '07.15', '15 menit', '15.30', 'Hari kerja penuh'],
          ['Selasa', '07.15', '15 menit', '15.30', 'Hari kerja penuh'],
          ['Rabu', '07.15', '15 menit', '15.30', 'Hari kerja penuh'],
          ['Kamis', '07.15', '15 menit', '15.30', 'Hari kerja penuh'],
          ['Jumat', '07.15', '15 menit', '11.00', 'Pulang lebih cepat'],
          ['Sabtu', '07.30', '15 menit', '12.00', 'Setengah hari'],
          ['Minggu', '-', '-', '-', <Badge variant="danger">Libur</Badge>],
        ]}
      />
      <Callout type="info" title="Fitur Tambahan Jadwal">
        <ul className="list-disc pl-4 space-y-1">
          <li><strong>Jadwal Khusus/Seasonal:</strong> Admin dapat membuat set jadwal khusus (Ramadhan, Ujian, Libur Semester) dengan rentang tanggal efektif.</li>
          <li><strong>Penanggalan Libur Nasional:</strong> Integrasi kalender libur nasional Indonesia (otomatis atau manual).</li>
          <li><strong>Preview Jadwal:</strong> Tampilan kalender mingguan/bulanan yang menampilkan jadwal aktif.</li>
        </ul>
      </Callout>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">4.2 Toleransi Keterlambatan</h3>
      <Table
        headers={['Parameter', 'Spesifikasi']}
        rows={[
          ['Default toleransi', '15 menit'],
          ['Rentang', '0-60 menit, per hari'],
          ['Logika', 'Di dalam toleransi -> "Tepat Waktu". Setelah toleransi -> "Terlambat" dengan menit keterlambatan tercatat.'],
          ['Dinamis', 'Dapat diubah per hari, per musim (Ramadhan), atau per kebijakan khusus.'],
        ]}
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">4.3 Pengaturan Koordinat Sekolah</h3>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card icon={<Map className="w-5 h-5" />} title="Antarmuka Admin">
          <ul className="list-disc pl-4 space-y-1">
            <li>Peta Google Maps interaktif dengan marker draggable.</li>
            <li>Admin menyeret marker ke titik pusat sekolah yang akurat.</li>
            <li>Lingkaran radius 300 meter ditampilkan (default terkunci 300 m).</li>
            <li>Input manual Latitude/Longitude untuk presisi.</li>
            <li>Tombol "Gunakan Lokasi Saya" untuk kalibrasi dari posisi admin.</li>
          </ul>
        </Card>
        <Card title="Penguncian">
          <ul className="list-disc pl-4 space-y-1">
            <li>Perubahan koordinat hanya oleh Super Admin atau Admin TU.</li>
            <li>Setiap perubahan tercatat di audit trail.</li>
            <li>Radius default 300 m dapat diubah hanya dengan konfirmasi ganda + alasan.</li>
          </ul>
        </Card>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">4.4 Jadwal Kerja & Shifting</h3>
      <Table
        headers={['Tipe Guru', 'Aturan']}
        rows={[
          ['Guru PNS (jam penuh)', 'Jam masuk-pulang standar Senin-Sabtu.'],
          ['Guru Honorer (harian)', 'Jam kerja fleksibel, dihitung per jam kerja. Absen datang + pulang wajib untuk perhitungan honor harian.'],
          ['Guru Piket', 'Jadwal piket pagi/siang/sore, dapat berbeda dari jam standar. Berdasarkan jadwal piket yang diinput admin.'],
          ['Guru Lembur', 'Pencatatan jam lembur otomatis jika scan pulang melebihi jam standar + lebih dari 1 jam. Admin approve/reject lembur.'],
          ['Guru Tidak Penuh', 'Jadwal khusus per guru, admin input jadwal mengajar. Absensi dihitung berdasarkan jam mengajar aktual.'],
        ]}
      />
    </div>
  );
}
