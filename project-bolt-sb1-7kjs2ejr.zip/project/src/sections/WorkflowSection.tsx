import SectionHeader from '@/components/SectionHeader';
import { Card, Callout } from '@/components/UI';
import { schoolInfo } from '@/data/specData';
import { Workflow, ShieldAlert, RefreshCw, FileText, Edit3 } from 'lucide-react';

export default function WorkflowSection() {
  return (
    <div>
      <SectionHeader
        number="Modul 8"
        title="Alur Kerja (Workflow) & SOP Singkat"
        subtitle="Alur pendaftaran wajah, validasi admin, absensi harian dengan GPS asli, dan penanganan manipulasi lokasi (Fake GPS)."
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">8.1 SOP Pendaftaran Guru Baru & Enrollment Wajah</h3>
      <div className="bg-slate-50 rounded-xl border border-slate-200 p-5 mb-8 overflow-x-auto">
        <pre className="text-xs text-slate-700 font-mono leading-relaxed">{`[Guru Baru Didaftarkan Admin]
      |
      v
[Admin input data guru: NIP, Nama, Email, PIN awal]
      |
      v
[Sistem kirim kredensial ke guru via WhatsApp/Email]
      |
      v
[Guru login pertama di portal guru (${schoolInfo.portalGuruUrl})]
      |
      v
[Sistem paksa ganti PIN]
      |
      v
[Guru buka menu "Daftar Wajah"]
      |
      v
[Guru lakukan Face Enrollment (dari mana saja)]
   - 3-5 frame dari sudut berbeda
   - Liveness check mini (kedip mata)
      |
      v
[Sistem generate face embedding -> simpan ke server]
      |
      v
[Status wajah = "Pending"]
      |
      v
[Notifikasi ke Admin: "Ada pendaftaran wajah menunggu validasi"]
      |
      v
[Admin buka menu "Persetujuan Wajah"]
   - Bandingkan foto enrollment vs foto profil resmi
      |
      +---[Approve]--> Status = "Active" -> Guru dapat absen
      |
      +---[Reject + alasan]--> Notifikasi ke guru -> Daftar ulang`}</pre>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">8.2 SOP Absensi Harian (Scan Wajah Datang/Pulang)</h3>
      <div className="bg-slate-50 rounded-xl border border-slate-200 p-5 mb-8 overflow-x-auto">
        <pre className="text-xs text-slate-700 font-mono leading-relaxed">{`[Guru tiba di sekolah (dalam radius 300 m)]
      |
      v
[Guru buka portal guru, login]
      |
      v
[Guru klik "Absen Sekarang"]
      |
      v
[Sistem cek lokasi (multi-source: GPS+GLONASS+Wi-Fi+Cell)]
      |
      +---[Di luar 300 m]--> Tombol scan terkunci + pesan
      |
      +---[Di dalam 300 m]
              |
              v
      [Sistem cek Anti-Mock Location]
              |
              +---[Mock terdeteksi]--> Absensi ditolak + log + notifikasi admin
              |
              +---[Lokasi asli]
                      |
                      v
              [Sistem cek jam kerja hari ini (Senin-Sabtu)]
                      |
                      +---[Di luar jam absen]--> Pesan "Belum dalam jam absen"
                      |
                      +---[Dalam jam absen]
                              |
                              v
                      [Kamera aktif -> Capture wajah]
                              |
                              v
                      [Liveness Detection (challenge + texture)]
                              |
                              +---[Gagal liveness]--> Absensi ditolak + pesan
                              |
                              +---[Lolos liveness]
                                      |
                                      v
                              [Generate embedding -> Match dengan embedding tersimpan]
                                      |
                                      +---[No match]--> Absensi ditolak + pesan
                                      |
                                      +---[Match (cosine >= 0.6)]
                                              |
                                              v
                                      [Rekam absensi: timestamp, koordinat, status]
                                              |
                                              +---[Online]--> Simpan ke cloud
                                              |
                                              +---[Offline]--> Simpan lokal -> Sync saat online
                                                      |
                                                      v
                                      [Notifikasi ke guru: "Absensi berhasil"]`}</pre>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">8.3 SOP Penanganan Manipulasi Lokasi (Fake GPS)</h3>
      <div className="bg-rose-50 rounded-xl border border-rose-200 p-5 mb-8 overflow-x-auto">
        <pre className="text-xs text-rose-700 font-mono leading-relaxed">{`[Sistem deteksi: Mock Location / Developer Options / Fake GPS]
      |
      v
[Absensi DITOLAK otomatis]
      |
      v
[Pesan ke guru: "Manipulasi lokasi terdeteksi. Hubungi Admin TU."]
      |
      v
[Log keamanan tercatat: guru ID, waktu, jenis manipulasi]
      |
      v
[Notifikasi ke Admin TU & Kepala Sekolah]
      |
      v
[Admin review log keamanan]
      |
      +---[False positive]--> Admin override status absen + catatan
      |
      +---[Manipulasi terkonfirmasi]
              |
              v
      [Teguran/sanksi sesuai aturan sekolah]
              |
              v
      [Jika berulang 3x -> akun dikunci sementara, wajib klarifikasi Kepsek]`}</pre>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">8.4 SOP Pengajuan Izin/Sakit/Dinas Luar</h3>
      <div className="bg-slate-50 rounded-xl border border-slate-200 p-5 mb-8 overflow-x-auto">
        <pre className="text-xs text-slate-700 font-mono leading-relaxed">{`[Guru tidak dapat hadir / harus dinas luar]
      |
      v
[Guru login portal guru -> menu "Pengajuan Izin"]
      |
      v
[Isi form: tipe, tanggal, alasan, upload surat bukti]
      |
      v
[Submit -> status "Pending"]
      |
      v
[Admin terima notifikasi -> review]
      |
      +---[Approve]--> Status absen tanggal terkait = sesuai tipe izin
      |                 +--> Notifikasi ke guru: "Pengajuan disetujui"
      |
      +---[Reject + alasan]--> Notifikasi ke guru: "Pengajuan ditolak"
                                +--> Guru wajib absen normal atau ajukan ulang`}</pre>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">8.5 SOP Override Absen oleh Admin</h3>
      <div className="bg-slate-50 rounded-xl border border-slate-200 p-5 mb-8 overflow-x-auto">
        <pre className="text-xs text-slate-700 font-mono leading-relaxed">{`[Ada guru status absen perlu dikoreksi]
      |
      v
[Admin login panel admin -> cari guru -> tanggal terkait]
      |
      v
[Klik "Override Status"]
      |
      v
[Pilih status baru + wajib isi catatan (min. 10 karakter)]
      |
      v
[Konfirmasi -> Simpan]
      |
      v
[Audit trail tercatat: admin, waktu, status lama->baru, catatan]
      |
      v
[Notifikasi ke guru: "Status absen Anda diperbarui oleh Admin"]`}</pre>
      </div>
    </div>
  );
}
