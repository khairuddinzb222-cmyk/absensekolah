import SectionHeader from '@/components/SectionHeader';
import { Card, Badge, Table, Callout } from '@/components/UI';
import {
  Calendar, FileText, PenLine, Users, KeyRound, Edit3,
  History, FileBarChart, Download, Settings,
} from 'lucide-react';

export default function AdminPanelSection() {
  return (
    <div>
      <SectionHeader
        number="Modul 7"
        title="Dashboard & Panel Kontrol Admin"
        subtitle="Pengaturan jadwal, kustomisasi laporan, manajemen data guru, reset kredensial, override absen, audit trail, dan laporan grafik."
      />

      <div className="grid md:grid-cols-2 gap-4 mb-8">
        <Card icon={<Calendar className="w-5 h-5" />} title="7.1 Pengaturan Jadwal Mingguan Manual">
          Halaman khusus bagi admin untuk mengedit jadwal jam masuk/pulang Senin-Sabtu kapan saja.
          Tabel 7 baris dengan time picker per sel, toggle aktif/nonaktif, dan dukungan jadwal khusus (Ramadhan, Ujian).
          Perubahan tercatat di audit trail.
        </Card>
        <Card icon={<FileText className="w-5 h-5" />} title="7.2 Kustomisasi Dokumen Laporan (Kop & Logo)">
          Upload logo sekolah (PNG/JPG transparan, maks 1 MB, auto-resize 200x200 px).
          Isi teks Kop Surat: nama sekolah, alamat, telepon, email, fax.
          Otomatis muncul di header setiap laporan cetak. Preview sebelum simpan.
        </Card>
        <Card icon={<PenLine className="w-5 h-5" />} title="7.3 Tanda Tangan Kepala Sekolah (Legalitas)">
          Tambah/edit nama Kepala Sekolah + NIP. Upload scan tanda tangan (PNG transparan, maks 500 KB).
          Upload stempel digital sekolah. Posisi: footer kanan laporan, di bawah tabel absensi.
          Tanggal cetak otomatis. Laporan siap cetak/unduh langsung legal secara administrasi.
        </Card>
        <Card icon={<Users className="w-5 h-5" />} title="7.4 Manajemen Data Guru Manual">
          Tambah manual satu per satu (form: NIP, Nama, Email, No. HP, Jabatan, Status, PIN awal, Foto).
          Tambah massal via Excel (template disediakan, validasi & preview sebelum import).
          Edit profil (NIP immutable setelah dibuat). Hapus (soft delete) / nonaktifkan.
        </Card>
        <Card icon={<KeyRound className="w-5 h-5" />} title="7.5 Reset Kredensial Guru">
          Lihat username guru (read-only). Reset PIN → generate 6 digit acak → tampilkan sekali → kirim via WhatsApp/Email.
          Force logout semua sesi guru (jika dugaan akun dibajak). Setiap reset tercatat di audit trail.
        </Card>
        <Card icon={<Edit3 className="w-5 h-5" />} title="7.6 Override Status Absen">
          Ubah status kehadiran manual (Hadir/Terlambat/Izin/Sakit/Dinas Luar/Alpha).
          Wajib isi catatan/alasan (min. 10 karakter). Sistem mencatat: admin, waktu, status lama → baru, catatan.
          Admin tidak dapat override absensi dirinya sendiri (anti self-deal).
        </Card>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">7.7 Histori Log Admin (Audit Trail)</h3>
      <p className="text-slate-600 mb-4">Rekam jejak digital otomatis yang mencatat aktivitas admin secara mendetail untuk menghindari penyalahgunaan wewenang.</p>
      <Table
        headers={['Aktivitas Tercatat', 'Field Log']}
        rows={[
          ['Login/Logout admin', 'Timestamp, admin ID, IP, device'],
          ['Edit jadwal', 'Timestamp, admin ID, perubahan lama->baru'],
          ['Approve/Reject wajah', 'Timestamp, admin ID, guru ID, aksi'],
          ['Reset Face ID', 'Timestamp, admin ID, guru ID'],
          ['Reset kredensial', 'Timestamp, admin ID, guru ID, tipe reset'],
          ['Tambah/edit/hapus guru', 'Timestamp, admin ID, guru ID, aksi'],
          ['Override absen', 'Timestamp, admin ID, guru ID, status lama->baru, catatan'],
          ['Edit koordinat sekolah', 'Timestamp, admin ID, koordinat lama->baru'],
          ['Edit kop/logo/ttd', 'Timestamp, admin ID, elemen yang diubah'],
          ['Perubahan IP whitelist', 'Timestamp, admin ID, IP lama->baru'],
        ]}
      />
      <Callout type="warning" title="Penyimpanan Audit Trail">
        Log immutable (append-only), retensi minimal 2 tahun, dapat di-export. Hanya Super Admin yang dapat melihat
        audit trail penuh; Admin TU melihat log aktivitasnya sendiri.
      </Callout>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">7.8 Laporan & Grafik</h3>
      <Table
        headers={['Laporan', 'Format']}
        rows={[
          ['Harian', 'Tabel per guru: jam datang, jam pulang, status, foto bukti. Kop + logo + ttd.'],
          ['Mingguan', 'Rekap per guru: total hadir, terlambat, izin, alpha. Grafik bar.'],
          ['Bulanan', 'Matrix guru x tanggal, status per hari. Grafik pie (distribusi status). Grafik line (tren kehadiran).'],
          ['Ekspor', <Badge variant="success">Excel (.xlsx)</Badge>, ' dan ', <Badge variant="success">PDF (kop, logo, ttd, stempel)</Badge>],
          ['Filter', 'Per guru, per tanggal, per status, per jabatan'],
          ['Rekap Keterlambatan', 'Total menit terlambat per guru per bulan (untuk payroll)'],
        ]}
      />
    </div>
  );
}
