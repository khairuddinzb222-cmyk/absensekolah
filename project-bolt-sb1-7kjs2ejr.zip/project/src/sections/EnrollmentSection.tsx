import SectionHeader from '@/components/SectionHeader';
import { Card, Badge, Table, Callout } from '@/components/UI';
import { ScanFace, CheckCircle2, RefreshCw, Image as ImageIcon, Fingerprint, Eye } from 'lucide-react';

export default function EnrollmentSection() {
  return (
    <div>
      <SectionHeader
        number="Modul 2"
        title="Pendaftaran Wajah & Validasi"
        subtitle="Mekanisme enrollment wajah fleksibel dari mana saja, dengan validasi manual admin untuk mencegah pendaftaran wajah orang lain."
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">2.1 Pendaftaran Fleksibel (Face Enrollment)</h3>
      <p className="text-slate-600 leading-relaxed mb-4">
        Guru dapat melakukan pendaftaran wajah pertama kali dari mana saja (rumah, kafe, mana pun) melalui aplikasi portal guru.
        Tidak ada batasan geofencing pada tahap enrollment.
      </p>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card icon={<ScanFace className="w-5 h-5" />} title="Alur Pendaftaran">
          <ol className="list-decimal pl-4 space-y-1">
            <li>Guru login di portal guru, buka menu "Daftar Wajah".</li>
            <li>Kamera depan aktif, sistem memberikan panduan framing wajah (oval guide).</li>
            <li>Sistem menangkap 3-5 frame dari sudut berbeda (depan, toleh kiri, toleh kanan).</li>
            <li>Liveness check mini: kedipkan mata, buka mulut (mencegah foto statis).</li>
            <li>Frame dikonversi menjadi face embedding (vektor 512 dimensi) via FaceNet/ArcFace.</li>
            <li>Status wajah berubah menjadi <Badge variant="warning">Pending</Badge>.</li>
          </ol>
        </Card>
        <Card icon={<Fingerprint className="w-5 h-5" />} title="Spesifikasi Teknis">
          <ul className="list-disc pl-4 space-y-1">
            <li>Model: FaceNet (512-d) atau ArcFace (512-d), akurasi ≥ 99.5% pada LFW.</li>
            <li>Threshold kemiripan (cosine similarity): ≥ 0.6, dapat dikalibrasi admin.</li>
            <li>Anti-spoofing: liveness detection berbasis kedip mata + analisis tekstur.</li>
            <li>Penyimpanan: hanya vektor embedding di server, bukan foto mentah (privasi).</li>
          </ul>
        </Card>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">2.2 Validasi Admin (Approval Workflow)</h3>
      <Callout type="warning" title="Status Pending">
        Wajah yang baru didaftarkan oleh guru berstatus "Pending" dan <strong>tidak dapat digunakan untuk absensi</strong> sampai
        Admin melakukan verifikasi manual di panel admin.
      </Callout>
      <Card icon={<Eye className="w-5 h-5" />} title="Alur Validasi di Panel Admin" className="mb-4">
        <ol className="list-decimal pl-4 space-y-1">
          <li>Admin buka menu "Persetujuan Wajah" di panel admin.</li>
          <li>Sistem menampilkan daftar guru berstatus Pending, lengkap dengan foto referensi enrollment, foto profil resmi (Dapodik), dan data identitas (NIP, nama, jabatan).</li>
          <li>Admin membandingkan kedua foto secara visual untuk memastikan kesesuaian identitas.</li>
          <li><strong>Approve</strong> → status "Active", guru dapat absen. <strong>Reject</strong> → status "Rejected" + wajib isi alasan, guru diminta daftar ulang.</li>
          <li>Setiap aksi approve/reject tercatat di audit trail (admin siapa, kapan, guru siapa).</li>
        </ol>
      </Card>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">2.3 Reset Face ID</h3>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card icon={<RefreshCw className="w-5 h-5" />} title="Tombol Reset Face ID">
          <ul className="list-disc pl-4 space-y-1">
            <li>Menghapus embedding wajah yang ada.</li>
            <li>Status wajah guru menjadi "Not Enrolled".</li>
            <li>Notifikasi otomatis ke guru (WhatsApp/Email) berisi instruksi pendaftaran ulang.</li>
            <li>Aktivitas reset tercatat di audit trail.</li>
          </ul>
        </Card>
        <Card title="Skenario Penggunaan">
          <ul className="list-disc pl-4 space-y-1">
            <li>Kendala pemindaian berulang (perubahan wajah signifikan, operasi, cedera).</li>
            <li>Dugaan kebocoran/penyalahgunaan data wajah.</li>
            <li>Guru keluar/mutasi dan data wajah perlu dibersihkan.</li>
          </ul>
        </Card>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">2.4 Kompresi Gambar Otomatis</h3>
      <p className="text-slate-600 mb-4">Sistem otomatis memperkecil ukuran file foto wajah hasil enrollment dan dokumen izin sebelum disimpan ke server.</p>
      <Table
        headers={['Parameter', 'Spesifikasi']}
        rows={[
          ['Format input', 'JPEG, PNG, WebP'],
          ['Format output', 'WebP (foto wajah), JPEG (dokumen izin)'],
          ['Resolusi foto wajah', 'Maks 800x800 px (cukup untuk face embedding)'],
          ['Resolusi dokumen izin', 'Maks 1500x2000 px (terbaca jelas)'],
          ['Ukuran file foto wajah', '<= 150 KB setelah kompresi'],
          ['Ukuran file dokumen izin', '<= 500 KB setelah kompresi'],
          ['Algoritma', 'Kompresi lossy adaptif (quality 80), Lanczos resampling'],
          ['Implementasi', 'Server-side (Sharp/libvips untuk Node, Pillow untuk Python)'],
        ]}
      />
    </div>
  );
}
