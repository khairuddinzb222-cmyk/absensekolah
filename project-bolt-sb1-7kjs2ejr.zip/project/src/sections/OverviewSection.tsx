import { schoolInfo } from '@/data/specData';
import { Card, Badge, Table, Callout } from '@/components/UI';
import {
  ShieldCheck, ScanFace, MapPin, Clock, Bell, UserCog, LayoutDashboard,
  Workflow, BookOpen, Database, School, Globe, Lock, Fingerprint,
  WifiOff, Zap, FileText, GraduationCap,
} from 'lucide-react';

export default function OverviewSection() {
  return (
    <div>
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-50 text-sky-700 text-xs font-semibold mb-3 border border-sky-100">
          <FileText className="w-3.5 h-3.5" /> Dokumen Resmi v1.0
        </div>
        <h1 className="text-3xl md:text-4xl font-bold text-slate-800 tracking-tight">
          Spesifikasi Kebutuhan Sistem, SOP & Buku Panduan
        </h1>
        <p className="mt-2 text-lg text-slate-500">Aplikasi Absensi Harian Guru Berbasis Scan Wajah (Face Recognition)</p>
        <p className="mt-1 text-sm text-slate-400">{schoolInfo.name} &middot; {schoolInfo.address}</p>
      </div>

      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <div className="bg-gradient-to-br from-sky-500 to-cyan-500 rounded-xl p-5 text-white shadow-md">
          <School className="w-7 h-7 mb-2 opacity-90" />
          <p className="text-sm opacity-80">Instansi</p>
          <p className="font-semibold leading-tight">{schoolInfo.name}</p>
        </div>
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 rounded-xl p-5 text-white shadow-md">
          <Globe className="w-7 h-7 mb-2 opacity-90" />
          <p className="text-sm opacity-80">Portal Guru</p>
          <p className="font-mono text-sm leading-tight break-all">{schoolInfo.portalGuruUrl}</p>
        </div>
        <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-xl p-5 text-white shadow-md">
          <Lock className="w-7 h-7 mb-2 opacity-90" />
          <p className="text-sm opacity-80">Portal Admin</p>
          <p className="font-mono text-sm leading-tight break-all">{schoolInfo.portalAdminUrl}</p>
        </div>
      </div>

      <div className="prose prose-slate max-w-none mb-8">
        <p className="text-slate-600 leading-relaxed">
          Dokumen ini berisi spesifikasi kebutuhan perangkat lunk (Software Requirements Specification),
          Standar Operasional Prosedur (SOP), serta Buku Panduan Pengguna lengkap untuk sistem absensi
          harian guru berbasis pengenalan wajah. Sistem dirancang meniru sekolah modern yang telah sukses
          menjalankan absensi digital secara penuh dan aman dari kecurangan, dengan fokus pada akurasi
          lokasi (geofencing 300 meter), deteksi keaslian wajah (liveness detection), dan pemisahan jalur
          akses guru-admin.
        </p>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4">Ringkasan Modul Sistem</h3>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {[
          { icon: ShieldCheck, title: 'Keamanan Akses', desc: 'Pemisahan URL guru & admin, SSL/HTTPS, IP Whitelisting, login berlapis.' },
          { icon: ScanFace, title: 'Pendaftaran Wajah', desc: 'Enrollment fleksibel dari mana saja, validasi admin, reset Face ID, kompresi gambar.' },
          { icon: MapPin, title: 'Geofencing 300m', desc: 'Kunci koordinat sekolah, anti-mock location, multi-source GPS/Wi-Fi.' },
          { icon: Clock, title: 'Manajemen Waktu', desc: 'Jadwal Senin-Sabtu, toleransi terlambat, shifting guru honorer & piket.' },
          { icon: Bell, title: 'Integrasi & Notifikasi', desc: 'WhatsApp Gateway, Email, payroll, ekspor Dapodik.' },
          { icon: UserCog, title: 'Portal Mandiri Guru', desc: 'Pengajuan izin/sakit/dinas, riwayat kehadiran real-time.' },
          { icon: LayoutDashboard, title: 'Panel Admin', desc: 'Kelola guru, jadwal, kop surat, ttd kepsek, audit trail, laporan.' },
          { icon: Workflow, title: 'Alur Kerja & SOP', desc: 'Alur enrollment, absensi harian, penanganan fake GPS.' },
          { icon: BookOpen, title: 'Buku Panduan', desc: 'Panduan terpisah untuk Guru dan Admin/Pengelola.' },
        ].map((m, i) => (
          <Card key={i} icon={<m.icon className="w-5 h-5" />} title={m.title}>
            {m.desc}
          </Card>
        ))}
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4">Informasi Lokasi Sekolah</h3>
      <Table
        headers={['Parameter', 'Nilai']}
        rows={[
          ['Nama Lokasi', schoolInfo.name],
          ['Alamat', schoolInfo.address],
          ['Latitude', schoolInfo.lat + ' (perkiraan, dikunci admin via Google Maps)'],
          ['Longitude', schoolInfo.lng + ' (perkiraan, dikunci admin via Google Maps)'],
          ['Radius Geofence', <Badge variant="info">{schoolInfo.radius}</Badge>],
          ['Rumus Jarak', 'Haversine formula (akurasi +/- 1 meter pada jarak pendek)'],
        ]}
      />

      <Callout type="info" title="Klasifikasi Dokumen">
        Dokumen ini siap diberikan kepada tim developer software sebagai acuan pengembangan (SRS),
        maupun langsung dicetak sebagai panduan resmi sekolah untuk Kepala Sekolah, Admin TU, dan para guru.
      </Callout>
    </div>
  );
}
