import SectionHeader from '@/components/SectionHeader';
import { Card, Table, Badge, Callout } from '@/components/UI';
import { Database, Server, Smartphone, ShieldCheck, Zap } from 'lucide-react';

export default function TechAppendixSection() {
  return (
    <div>
      <SectionHeader
        number="Lampiran"
        title="Lampiran Teknis"
        subtitle="Arsitektur sistem, skema database ringkas, prioritas pengembangan, dan non-functional requirements."
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">A. Arsitektur Sistem (Ringkasan)</h3>
      <div className="bg-slate-900 rounded-xl p-5 mb-8 overflow-x-auto">
        <pre className="text-xs text-slate-300 font-mono leading-relaxed">{`+-----------------------------------------------------------+
|                PENGGUNA (Guru & Admin)                     |
|           Browser / PWA di HP, Tablet, Laptop              |
+-------------------+-------------------+-------------------+
                    | HTTPS (TLS 1.2/1.3)  |
                    v                     v
         +----------------+      +----------------+
         |  Portal Guru   |      |  Portal Admin  |
         |  (publik)       |      |  (IP Whitelist) |
         +-------+--------+      +--------+-------+
                 |                          |
                 +----------+--+------------+
                            v
              +-------------------------+
              |   API Gateway / Reverse  |
              |   Proxy (Nginx/Cloudflare)|
              +-----------+-------------+
                          v
          +-------------------------------+
          |     Application Server        |
          | (Auth, Absensi, Laporan, DLL) |
          +---+----------+----------+----+
              |          |          |
              v          v          v
         +--------+ +--------+ +----------+
         |Database| |Object  | |Face Rec  |
         |(Postgres| |Storage | |Engine    |
         |/Supabase)| |(foto) | |(FaceNet/ |
         +--------+ +--------+ |ArcFace)  |
                               +----------+
                          |
              +-----------+-----------+
              v                     v
         +-----------+      +-----------+
         | WhatsApp  |      | Email SMTP|
         | Gateway   |      | (SendGrid)|
         +-----------+      +-----------+`}</pre>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">B. Daftar Entitas Data (Skema Database Ringkas)</h3>
      <Table
        headers={['Tabel', 'Deskripsi', 'Field Utama']}
        rows={[
          ['admin', 'Data admin', 'id, username, password_hash, role, 2fa_secret, last_login'],
          ['teacher', 'Data guru', 'id, nip, name, email, phone, jabatan, status_kepegawaian, pin_hash, face_status, face_embedding, photo_url, is_active'],
          ['face_enrollment', 'Riwayat pendaftaran wajah', 'id, teacher_id, status, photo_ref, embedding, created_at, approved_by, approved_at'],
          ['attendance', 'Record absensi harian', 'id, teacher_id, date, check_in, check_out, status, lat, lng, distance_m, photo_proof_url, is_mock, sync_status'],
          ['weekly_schedule', 'Jadwal mingguan', 'id, day, check_in_time, check_out_time, tolerance_minutes, is_active'],
          ['special_schedule', 'Jadwal khusus (Ramadhan dll)', 'id, name, start_date, end_date, schedule_json'],
          ['leave_request', 'Pengajuan izin/sakit/dinas', 'id, teacher_id, type, start_date, end_date, reason, document_url, status, approved_by, approved_at'],
          ['school_setting', 'Pengaturan sekolah', 'id, name, address, lat, lng, geofence_radius, logo_url, kop_text, principal_name, principal_nip, principal_signature_url, stamp_url'],
          ['admin_audit_log', 'Audit trail', 'id, admin_id, action, target_type, target_id, old_value, new_value, note, ip, device, created_at'],
          ['notification_log', 'Log notifikasi', 'id, recipient, channel, message, status, sent_at'],
          ['ip_whitelist', 'IP yang diizinkan akses admin', 'id, ip_range, label, created_by, created_at'],
        ]}
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">C. Daftar Prioritas Pengembangan</h3>
      <Table
        headers={['Prioritas', 'Modul', 'Catatan']}
        rows={[
          [<Badge variant="danger">P0</Badge>, 'Auth guru & admin, URL separation, SSL, IP whitelist', 'Fondasi keamanan'],
          [<Badge variant="danger">P0</Badge>, 'Face enrollment + approval admin', 'Inti pendaftaran'],
          [<Badge variant="danger">P0</Badge>, 'Geofencing 300 m + anti-mock location', 'Inti absensi'],
          [<Badge variant="danger">P0</Badge>, 'Liveness detection', 'Anti-kecurangan'],
          [<Badge variant="danger">P0</Badge>, 'Scan wajah < 2 detik', 'Performa'],
          [<Badge variant="warning">P1</Badge>, 'Jadwal Senin-Sabtu + toleransi', 'Manajemen waktu'],
          [<Badge variant="warning">P1</Badge>, 'Portal guru (riwayat, pengajuan izin)', 'Self-service'],
          [<Badge variant="warning">P1</Badge>, 'Dashboard admin + laporan', 'Pengelolaan'],
          [<Badge variant="warning">P1</Badge>, 'Audit trail', 'Akuntabilitas'],
          [<Badge variant="info">P2</Badge>, 'Mode offline + sync', 'Ketahanan'],
          [<Badge variant="info">P2</Badge>, 'Kop/logo/ttd/stempel laporan', 'Legalitas cetak'],
          [<Badge variant="info">P2</Badge>, 'WhatsApp/Email gateway', 'Notifikasi'],
          [<Badge variant="success">P3</Badge>, 'Payroll integration', 'Penggajian'],
          [<Badge variant="success">P3</Badge>, 'Dapodik export', 'Pelaporan'],
          [<Badge variant="success">P3</Badge>, 'Shifting guru honorer/piket/lembur', 'Skenario khusus'],
        ]}
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">D. Non-Functional Requirements</h3>
      <div className="grid md:grid-cols-2 gap-4 mb-8">
        <Card icon={<Zap className="w-5 h-5" />} title="Performa">
          Scan wajah di bawah 2 detik; dashboard load di bawah 3 detik; API response di bawah 500 ms.
        </Card>
        <Card icon={<Server className="w-5 h-5" />} title="Skalabilitas & Ketersediaan">
          Mendukung 100+ guru (skala SMP); uptime ≥ 99.5% (downtime maks 3.6 jam/tahun).
        </Card>
        <Card icon={<ShieldCheck className="w-5 h-5" />} title="Keamanan">
          TLS 1.2/1.3, bcrypt/argon2, JWT, RBAC, audit trail, IP whitelist, anti-mock, liveness.
        </Card>
        <Card icon={<Smartphone className="w-5 h-5" />} title="Kompatibilitas">
          Chrome, Safari, Firefox, Edge (2 versi terakhir); Android 8+, iOS 12+, Windows, macOS.
        </Card>
      </div>
      <Table
        headers={['Kategori', 'Spesifikasi']}
        rows={[
          ['Privasi', 'Data wajah disimpan sebagai embedding (bukan foto mentah); kepatuhan UU PDP Indonesia'],
          ['Aksesibilitas', 'WCAG 2.1 AA (kontras, navigasi keyboard, label form)'],
          ['Backup', 'Database backup harian otomatis; retensi 30 hari; disaster recovery RTO 4 jam'],
          ['Lokasi Server', 'Cloud (Supabase / regional Indonesia/Singapura) untuk latensi rendah'],
        ]}
      />

      <Callout type="success" title="Dokumen Siap Distribusi">
        Dokumen ini siap diberikan kepada tim developer software sebagai acuan pengembangan (SRS),
        maupun langsung dicetak sebagai panduan resmi sekolah untuk Kepala Sekolah, Admin TU, dan para guru.
      </Callout>
    </div>
  );
}
