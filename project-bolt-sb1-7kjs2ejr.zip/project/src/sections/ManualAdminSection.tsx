import SectionHeader from '@/components/SectionHeader';
import { Card, Callout, Step } from '@/components/UI';
import { schoolInfo } from '@/data/specData';
import {
  Lock, ScanFace, Calendar, Users, Map, FileText, PenLine,
  FileBarChart, Edit3, History, Download,
} from 'lucide-react';

export default function ManualAdminSection() {
  return (
    <div>
      <SectionHeader
        number="Panduan B"
        title="Panduan untuk Admin/Pengelola"
        subtitle="Panduan lengkap untuk peran Admin - login, validasi wajah, jadwal, data guru, koordinat sekolah, laporan, override, audit trail."
      />

      <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-xl p-5 text-white mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Lock className="w-6 h-6" />
          <h3 className="text-lg font-semibold">Link Akses Khusus Admin</h3>
        </div>
        <p className="font-mono text-lg break-all bg-white/10 rounded-lg px-3 py-2">{schoolInfo.portalAdminUrl}</p>
        <p className="text-sm mt-2 opacity-90">
          Hanya dapat diakses dari jaringan internal sekolah (Wi-Fi/LAN TU, Kepsek) karena dilindungi IP Whitelisting. Tidak muncul di Google. Sesi otomatis logout setelah 15 menit tidak aktif.
        </p>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <Lock className="w-5 h-5 text-amber-600" /> Login Admin
      </h3>
      <div className="mb-8">
        <Step step={1} title="Pastikan Jaringan Internal">
          Pastikan perangkat terhubung ke jaringan internal sekolah (Wi-Fi/LAN TU).
        </Step>
        <Step step={2} title="Buka Portal Admin">
          Buka browser dan kunjungi <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">{schoolInfo.portalAdminUrl}</code>.
        </Step>
        <Step step={3} title="Masukkan Kredensial">
          Masukkan <strong>Username</strong> dan <strong>Password</strong> (min. 12 karakter, kombinasi huruf besar, kecil, angka, simbol). Jika 2FA aktif, masukkan kode Google Authenticator. Klik "Masuk".
        </Step>
      </div>
      <Callout type="warning" title="Kebijakan Password Admin">
        Password wajib diganti setiap 90 hari. Tidak boleh sama dengan 5 password terakhir. Jika 5 kali gagal login, akun terkunci 30 menit + notifikasi ke Kepala Sekolah.
      </Callout>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <ScanFace className="w-5 h-5 text-amber-600" /> Memvalidasi (Approve/Reject) Pendaftaran Wajah
      </h3>
      <div className="mb-8">
        <Step step={1} title="Buka Menu Persetujuan Wajah">
          Lihat notifikasi "Pendaftaran Wajah Menunggu Validasi" di dashboard, atau buka menu "Persetujuan Wajah".
        </Step>
        <Step step={2} title="Bandingkan Foto">
          Anda melihat daftar guru Pending dengan foto hasil enrollment, foto profil resmi (Dapodik), dan data identitas. Bandingkan kedua foto untuk memastikan kesesuaian.
        </Step>
        <Step step={3} title="Approve atau Reject">
          Jika sesuai: klik "Approve" → status "Active", guru dapat absen. Jika tidak sesuai: klik "Reject" + isi alasan → guru diminta daftar ulang. Setiap aksi tercatat di Audit Trail.
        </Step>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <Calendar className="w-5 h-5 text-amber-600" /> Mengedit Jam Masuk/Pulang Harian (Senin-Sabtu)
      </h3>
      <div className="mb-8">
        <Step step={1} title="Buka Pengaturan Jadwal">
          Buka menu "Pengaturan Jadwal". Anda melihat tabel jadwal mingguan (7 baris Senin-Sabtu).
        </Step>
        <Step step={2} title="Edit Jam">
          Klik sel yang ingin diubah (jam masuk/pulang/toleransi) → gunakan time picker. Untuk menonaktifkan hari tertentu, klik toggle "Aktif".
        </Step>
        <Step step={3} title="Jadwal Khusus (Opsional)">
          Untuk jadwal Ramadhan/Ujian: klik "+ Jadwal Khusus", beri nama, atur jam per hari, tentukan rentang tanggal efektif, simpan.
        </Step>
        <Step step={4} title="Simpan">
          Klik "Simpan Perubahan" → preview → konfirmasi "Ya, Simpan". Perubahan tercatat di Audit Trail.
        </Step>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <Users className="w-5 h-5 text-amber-600" /> Mengelola Data Guru
      </h3>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card title="Tambah Manual (Satu per Satu)">
          Menu "Data Guru" → "+ Tambah Guru" → isi form (NIP, Nama, Email, No. HP, Jabatan, Status, PIN Awal, Foto) → Simpan. Sistem kirim kredensial ke guru via WhatsApp/Email.
        </Card>
        <Card title="Tambah Massal via Excel">
          Menu "Data Guru" → "Import Massal" → "Unduh Template Excel" → isi template → upload → sistem validasi & preview → "Konfirmasi Import".
        </Card>
        <Card title="Edit Profil Guru">
          "Data Guru" → cari guru → klik nama → "Edit" → ubah field (NIP tidak dapat diubah) → Simpan. Tercatat di Audit Trail.
        </Card>
        <Card title="Hapus/Nonaktifkan Guru">
          "Data Guru" → detail guru → "Nonaktifkan" (soft delete, data tersimpan) atau "Hapus Permanen" (hanya Super Admin, konfirmasi ganda).
        </Card>
      </div>
      <Callout type="info" title="Reset Password/PIN Guru">
        "Data Guru" → detail guru → bagian "Kredensial": klik "Lihat Username" (read-only), klik "Reset PIN" → sistem generate PIN baru 6 digit acak → tampilkan sekali → "Kirim ke Guru" via WhatsApp/Email. Guru wajib ganti PIN saat login berikutnya. Aksi tercatat di Audit Trail.
      </Callout>
      <Callout type="info" title="Reset Face ID Guru">
        "Data Guru" → detail guru → bagian "Data Wajah" → "Reset Face ID" → konfirmasi. Embedding wajah dihapus, status "Not Enrolled". Sistem kirim notifikasi ke guru untuk daftar ulang. Aksi tercatat di Audit Trail.
      </Callout>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <Map className="w-5 h-5 text-amber-600" /> Mengatur Koordinat Sekolah, Kop Surat, Logo, & Tanda Tangan
      </h3>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card icon={<Map className="w-5 h-5" />} title="Titik Koordinat Sekolah (Google Maps)">
          Menu "Pengaturan Lokasi" → peta Google Maps interaktif. Seret marker ke titik pusat sekolah, atau input manual Lat/Long, atau "Gunakan Lokasi Saya". Lingkaran radius 300 m ditampilkan. Simpan. Tercatat di Audit Trail.
        </Card>
        <Card icon={<FileText className="w-5 h-5" />} title="Kop Surat & Logo">
          Menu "Pengaturan Laporan" → tab "Kop & Logo". Upload logo (PNG/JPG transparan, maks 1 MB). Isi nama sekolah, alamat, telepon, email. Simpan → Preview.
        </Card>
        <Card icon={<PenLine className="w-5 h-5" />} title="Tanda Tangan Kepala Sekolah & Stempel">
          Menu "Pengaturan Laporan" → tab "Tanda Tangan & Stempel". Isi nama + NIP Kepsek. Upload scan tanda tangan (PNG transparan, maks 500 KB). Upload stempel digital. Atur posisi (default: footer kanan). Simpan → Preview.
        </Card>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <FileBarChart className="w-5 h-5 text-amber-600" /> Laporan, Override, Audit Trail & Unduh Laporan
      </h3>
      <div className="mb-4">
        <Step step={1} title="Cek Laporan Harian/Bulanan">
          Buka menu "Laporan". Pilih harian (tabel per guru), mingguan (rekap + grafik bar), atau bulanan (matrix + grafik pie + line). Gunakan filter jika perlu.
        </Step>
        <Step step={2} title="Override Absen Manual">
          Buka "Laporan Harian" → pilih tanggal → cari guru → "Override Status" → pilih status baru + isi catatan (min. 10 karakter) → Simpan. Sistem mencatat di Audit Trail + notifikasi ke guru.
        </Step>
        <Step step={3} title="Lihat Audit Trail">
          Buka menu "Audit Trail". Tabel log: timestamp, admin, aktivitas, detail, IP, perangkat. Filter per admin/tipe/tanggal. Export untuk arsip keamanan.
        </Step>
        <Step step={4} title="Unduh Laporan Berstempel Digital">
          Buka "Laporan" → pilih periode → "Unduh PDF" atau "Unduh Excel". File sudah lengkap: Kop Surat, Logo, Tabel absensi, Tanda Tangan Kepsek + NIP, Stempel Digital, Tanggal Cetak. Siap cetak dan legal secara administrasi.
        </Step>
      </div>
      <Callout type="danger" title="Catatan Anti Self-Deal">
        Admin tidak dapat melakukan override pada absensi dirinya sendiri. Setiap override wajib disertai catatan logis (min. 10 karakter).
      </Callout>
    </div>
  );
}
