import SectionHeader from '@/components/SectionHeader';
import { Card, Table, Callout } from '@/components/UI';
import { Send, DollarSign, GraduationCap } from 'lucide-react';

export default function IntegrationSection() {
  return (
    <div>
      <SectionHeader
        number="Modul 5"
        title="Integrasi & Notifikasi Otomatis"
        subtitle="Notifikasi WhatsApp/Email, integrasi penggajian, dan sinkronisasi format Dapodik."
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">5.1 Notifikasi Gateway (WhatsApp & Email)</h3>
      <Table
        headers={['Channel', 'Penerima', 'Konten', 'Waktu']}
        rows={[
          ['WhatsApp', 'Kepala Sekolah', 'Rekap singkat: total hadir, terlambat, izin, alpha', '08.00 & 16.00 harian'],
          ['WhatsApp', 'Admin TU', 'Detail rekap + daftar guru yang belum absen', '08.30 & 16.30 harian'],
          ['Email', 'Kepsek & TU', 'Laporan harian lengkap (PDF terlampir)', '17.00 harian'],
          ['WhatsApp', 'Guru (individu)', 'Konfirmasi absensi berhasil/gagal + status tepat waktu/terlambat', 'Real-time setelah scan'],
          ['WhatsApp', 'Guru (individu)', 'Pengingat jika belum absen sampai batas toleransi', '10 menit setelah toleransi'],
        ]}
      />
      <Card icon={<Send className="w-5 h-5" />} title="Teknologi" className="mb-4">
        <ul className="list-disc pl-4 space-y-1">
          <li>WhatsApp Gateway via API pihak ketiga (Wablas, Fonnte, Whacenter) atau WhatsApp Business API resmi.</li>
          <li>Email via SMTP (Gmail Workspace / SendGrid).</li>
          <li>Template pesan dapat dikustomisasi admin.</li>
          <li>Retry otomatis 3 kali jika pengiriman gagal, lalu log error.</li>
        </ul>
      </Card>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">5.2 Integrasi Penggajian (Payroll Integration)</h3>
      <Card icon={<DollarSign className="w-5 h-5" />} title="Fitur Payroll" className="mb-4">
        <ul className="list-disc pl-4 space-y-1">
          <li>Ekspor rekap bulanan per guru: total hadir, total terlambat (menit), total alpha (hari), total izin/sakit.</li>
          <li>Rumus pemotongan tunjangan dapat dikonfigurasi admin:
            <code className="text-xs bg-slate-100 px-1 py-0.5 rounded block mt-1">Potongan = (Menit terlambat x Rp X) + (Hari alpha x Rp Y)</code>
          </li>
          <li>Guru honorer: <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">Honor Harian = (Jam hadir x Rp Z) - Potongan</code></li>
          <li>Ekspor format Excel/CSV siap import ke sistem payroll eksternal.</li>
          <li>Template rumus fleksibel (admin input koefisien).</li>
          <li>Preview perhitungan sebelum ekspor.</li>
        </ul>
      </Card>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">5.3 Sinkronisasi Dapodik</h3>
      <Card icon={<GraduationCap className="w-5 h-5" />} title="Format Ekspor Dapodik" className="mb-4">
        <Table
          headers={['Data', 'Format Dapodik']}
          rows={[
            ['Data Guru', 'NIP, Nama, NIK, Tempat/Tanggal Lahir, Jenis Kelamin, Status Kepegawaian, Mata Pelajaran, Pendidikan'],
            ['Kehadiran Bulanan', 'Per guru: total hadir, sakit, izin, alpha, per bulan'],
            ['Ekspor', 'CSV/Excel sesuai template Dapodik (kolom & urutan sesuai standar)'],
          ]}
        />
      </Card>
      <Callout type="info" title="Implementasi Dapodik">
        Modul ekspor khusus dengan mapping kolom ke template Dapodik terbaru. Admin dapat memilih bulan dan tahun,
        lalu unduh file siap upload ke Dapodik.
      </Callout>
    </div>
  );
}
