import SectionHeader from '@/components/SectionHeader';
import { Card, Badge, Table, Callout } from '@/components/UI';
import { schoolInfo } from '@/data/specData';
import { Globe, Lock, KeyRound, ShieldCheck, Network, Server, Smartphone } from 'lucide-react';

export default function SecuritySection() {
  return (
    <div>
      <SectionHeader
        number="Modul 1"
        title="Keamanan Akses & Pemisahan Link Login"
        subtitle="Pemisahan jalur akses guru dan admin secara tegas untuk memperkecil permukaan serangan dan mencegah pencarian jalur admin oleh pihak tidak berwenang."
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">1.1 Pemisahan Link Akses (URL Separation)</h3>
      <p className="text-slate-600 leading-relaxed mb-4">
        Sistem wajib mengimplementasikan pemisahan jalur akses (URL) secara tegas antara portal Guru dan portal Admin.
        Subdomain admin tidak boleh tampil di hasil pencarian Google (meta <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">robots = noindex, nofollow</code>) dan
        dilindungi IP Whitelisting.
      </p>
      <Table
        headers={['Portal', 'URL Akses', 'Keterangan']}
        rows={[
          ['Portal Guru', <span className="font-mono text-xs break-all">{schoolInfo.portalGuruUrl}</span>, 'URL publik, dapat diakses dari jaringan mana pun.'],
          ['Portal Admin', <span className="font-mono text-xs break-all">{schoolInfo.portalAdminUrl}</span>, 'Subdomain khusus, noindex, dilindungi IP Whitelisting.'],
        ]}
      />
      <div className="grid md:grid-cols-2 gap-4 mb-8">
        <Card icon={<Globe className="w-5 h-5" />} title="Persyaratan Teknis Routing">
          <ul className="list-disc pl-4 space-y-1">
            <li>Reverse proxy (Nginx/Cloudflare) memisahkan trafik guru & admin di layer infrastruktur.</li>
            <li>Sertifikat SSL/TLS terpisah atau wildcard <code className="text-xs bg-slate-100 px-1 rounded">*.smpkartika14-1.sch.id</code>.</li>
            <li>Halaman admin tidak menampilkan form login yang dapat ditebak.</li>
          </ul>
        </Card>
        <Card icon={<Server className="w-5 h-5" />} title="Proteksi Tambahan">
          <ul className="list-disc pl-4 space-y-1">
            <li>Rate limiting: maksimum 5 percobaan login per menit per IP.</li>
            <li>CAPTCHA setelah 3 percobaan gagal.</li>
            <li>Notifikasi email ke Kepala Sekolah saat login admin dari IP baru.</li>
            <li>Session timeout admin: 15 menit idle.</li>
          </ul>
        </Card>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">1.2 Jalur Aman Admin (Network Security)</h3>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card icon={<Lock className="w-5 h-5" />} title="Enkripsi SSL/HTTPS">
          <ul className="list-disc pl-4 space-y-1">
            <li>HTTPS wajib dengan TLS 1.2/1.3. HTTP auto-redirect ke HTTPS (HSTS aktif).</li>
            <li>Sertifikat dari Let's Encrypt / komersial, auto-renewal.</li>
            <li>Cipher suite: forward secrecy, SSLv3/TLS 1.0/1.1 disabled.</li>
          </ul>
        </Card>
        <Card icon={<Network className="w-5 h-5" />} title="IP Whitelisting">
          <ul className="list-disc pl-4 space-y-1">
            <li>Portal admin hanya dari rentang IP jaringan internal sekolah (Wi-Fi/LAN TU, Kepsek).</li>
            <li>Implementasi di layer reverse proxy (Nginx allow/deny) atau WAF.</li>
            <li>Daftar IP dapat diperbarui Super Admin (dengan audit trail).</li>
            <li>Fallback darurat: token one-time via email Kepsek, berlaku 1 jam.</li>
          </ul>
        </Card>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">1.3 Gerbang Login Guru</h3>
      <p className="text-slate-600 mb-4">Metode login ringkas: <strong>NIP atau Email + PIN (6 digit)</strong>. Portal guru hanya menampilkan riwayat absensi pribadi dan pengajuan izin.</p>
      <Table
        headers={['Parameter', 'Spesifikasi']}
        rows={[
          ['Identifier', 'NIP (prioritas) atau Email resmi guru'],
          ['Kredensial', 'PIN 6 digit numerik'],
          ['PIN Awal', 'Dibuat admin saat pendaftaran; guru wajib ganti saat login pertama (force change)'],
          ['Kebijakan PIN', 'Tidak boleh berurutan (123456), tanggal lahir, atau berulang (111111)'],
          ['Percobaan Gagal', 'Akun terkunci 15 menit setelah 5 kali gagal + notifikasi admin'],
          ['Token Sesi', 'JWT berumur 12 jam'],
        ]}
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">1.4 Gerbang Login Admin</h3>
      <p className="text-slate-600 mb-4">Metode login aman: <strong>Username + Password Kompleks</strong> + (opsional) 2FA (TOTP / Google Authenticator).</p>
      <Table
        headers={['Parameter', 'Spesifikasi']}
        rows={[
          ['Username', 'Minimal 5 karakter, unik, case-sensitive'],
          ['Password', 'Minimal 12 karakter, wajib huruf besar + kecil + angka + simbol'],
          ['Riwayat Password', 'Tidak boleh sama dengan 5 password terakhir'],
          ['Masa Berlaku', '90 hari, wajib diganti'],
          ['Kunci Akun', '5 kali gagal -> kunci 30 menit + notifikasi Kepsek'],
          ['Sesi', '15 menit idle timeout, JWT + fingerprint perangkat'],
        ]}
      />
      <h4 className="font-semibold text-slate-700 mb-3 mt-4">Peran Admin (RBAC)</h4>
      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <Card title="Super Admin">
          Akses penuh: kelola admin lain, IP whitelist, reset kredensial admin.
        </Card>
        <Card title="Admin TU">
          Kelola data guru, jadwal, laporan, override absen.
        </Card>
        <Card title="Kepala Sekolah (read-only)">
          Lihat laporan, grafik, audit trail, tanpa hak edit.
        </Card>
      </div>

      <Callout type="warning" title="Catatan Keamanan">
        PIN guru bersifat ringkas karena portal guru hanya menampilkan data pribadi. Aksi sensitif
        (reset PIN, pendaftaran wajah) tetap memerlukan konfirmasi PIN ulang. Admin tidak dapat melakukan
        override pada absensi dirinya sendiri (anti self-deal).
      </Callout>
    </div>
  );
}
