import SectionHeader from '@/components/SectionHeader';
import { Card, Callout, Step } from '@/components/UI';
import { schoolInfo } from '@/data/specData';
import { Globe, KeyRound, ScanFace, MapPin, FileText, Calendar, BookOpen } from 'lucide-react';

export default function ManualTeacherSection() {
  return (
    <div>
      <SectionHeader
        number="Panduan A"
        title="Panduan untuk Guru"
        subtitle="Panduan lengkap penggunaan aplikasi untuk peran Guru - login, pendaftaran wajah, absensi harian, pengajuan izin, dan riwayat."
      />

      <div className="bg-gradient-to-br from-sky-500 to-cyan-500 rounded-xl p-5 text-white mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Globe className="w-6 h-6" />
          <h3 className="text-lg font-semibold">Link Akses Khusus Guru</h3>
        </div>
        <p className="font-mono text-lg break-all bg-white/10 rounded-lg px-3 py-2">{schoolInfo.portalGuruUrl}</p>
        <p className="text-sm mt-2 opacity-90">
          Dapat diakses dari perangkat apa pun (HP, tablet, laptop) dan dari jaringan mana pun. Batasan lokasi 300 meter hanya berlaku untuk scan wajah absensi harian.
        </p>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <KeyRound className="w-5 h-5 text-sky-600" /> Login Pertama Kali
      </h3>
      <div className="mb-8">
        <Step step={1} title="Buka Portal Guru">
          Buka browser (Chrome/Safari) di HP atau laptop. Kunjungi <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">{schoolInfo.portalGuruUrl}</code>.
        </Step>
        <Step step={2} title="Masukkan Kredensial">
          Pada halaman login, masukkan <strong>NIP</strong> atau <strong>Email</strong> (sesuai data dari Admin TU) dan <strong>PIN Awal</strong> 6 digit (diberikan Admin TU). Klik "Masuk".
        </Step>
        <Step step={3} title="Ganti PIN">
          Pada login pertama, sistem meminta Anda mengganti PIN. Masukkan PIN lama, lalu PIN baru 6 digit (hindari 123456, tanggal lahir, atau angka berulang). Konfirmasi PIN baru.
        </Step>
        <Step step={4} title="Masuk ke Beranda">
          Klik "Simpan PIN Baru". Anda masuk ke beranda portal guru.
        </Step>
      </div>
      <Callout type="info" title="Jika Lupa PIN">
        Hubungi Admin TU untuk reset PIN. Admin akan mengirim PIN baru sementara via WhatsApp/Email. Anda wajib mengganti PIN tersebut saat login berikutnya.
      </Callout>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <ScanFace className="w-5 h-5 text-sky-600" /> Mendaftarkan Wajah Pertama Kali (Face Enrollment)
      </h3>
      <p className="text-slate-600 mb-4">Pendaftaran wajah dapat dilakukan dari mana saja (rumah, kafe, mana pun) - tidak perlu di sekolah.</p>
      <div className="mb-8">
        <Step step={1} title="Buka Menu Daftar Wajah">
          Login ke portal guru. Klik menu "Daftar Wajah" di beranda atau sidebar.
        </Step>
        <Step step={2} title="Izinkan Kamera">
          Sistem meminta izin akses kamera. Klik "Izinkan".
        </Step>
        <Step step={3} title="Posisikan Wajah">
          Posisikan wajah di area oval. Hadap lurus, pencahayaan cukup, lepaskan masker/kacamata hitam.
        </Step>
        <Step step={4} title="Ikuti Instruksi Capture">
          Ikuti instruksi: "Hadap depan" → "Toleh kiri" → "Toleh kanan" → "Kedipkan mata 2 kali" (liveness check).
        </Step>
        <Step step={5} title="Menunggu Validasi Admin">
          Sistem menampilkan "Pendaftaran wajah berhasil. Menunggu validasi Admin." Status wajah Anda sekarang "Pending". Anda belum dapat absen sampai Admin menyetujui.
        </Step>
        <Step step={6} title="Terima Notifikasi Hasil">
          Anda menerima notifikasi (WhatsApp/Email) saat Admin menyetujui (status "Active", dapat absen) atau menolak (diminta daftar ulang dengan alasan).
        </Step>
      </div>
      <Callout type="success" title="Tips Pendaftaran Wajah Berkualitas">
        Lakukan di tempat dengan cahaya alami merata. Hindari latar belakang ramai/berpola. Pastikan hanya wajah Anda yang terlihat. Jangan gunakan foto cetak atau video - sistem akan menolak.
      </Callout>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <MapPin className="w-5 h-5 text-sky-600" /> Melakukan Scan Wajah Harian (Datang & Pulang)
      </h3>
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
        <p className="font-semibold text-amber-800 mb-2">SYARAT WAJIB sebelum scan:</p>
        <ul className="list-disc pl-5 text-sm text-amber-700 space-y-1">
          <li>Berada di dalam radius <strong>300 meter dari {schoolInfo.name}</strong> ({schoolInfo.address}).</li>
          <li>GPS perangkat <strong>AKTIF</strong> dengan mode <strong>"Akurasi Tinggi" (High Accuracy)</strong>.</li>
          <li><strong>Developer Options</strong> perangkat <strong>DIMATIKAN</strong> (nonaktifkan USB Debugging).</li>
          <li>Tidak menggunakan aplikasi Fake GPS atau pemalsu lokasi apa pun.</li>
          <li>Waktu scan dalam jam kerja hari ini (Senin-Sabtu, sesuai jadwal Admin).</li>
        </ul>
      </div>
      <div className="mb-8">
        <Step step={1} title="Buka Menu Absen">
          Login ke portal guru. Klik tombol "Absen Sekarang" di beranda.
        </Step>
        <Step step={2} title="Sistem Mendeteksi Lokasi">
          Sistem mendeteksi lokasi Anda dan menampilkan peta mini dengan marker sekolah, lingkaran radius 300 m, dan posisi Anda.
        </Step>
        <Step step={3} title="Tombol Scan Aktif (Jika di Dalam Radius)">
          Jika di dalam 300 m: tombol "Scan Wajah" aktif (hijau). Klik tombol tersebut. Jika di luar: tombol terkunci + pesan jarak. Jika dinas luar, gunakan menu Pengajuan Izin.
        </Step>
        <Step step={4} title="Scan Wajah">
          Posisikan wajah di area oval. Ikuti instruksi liveness (kedipkan mata, tersenyum). Tunggu pemrosesan (di bawah 2 detik).
        </Step>
        <Step step={5} title="Hasil Scan">
          Berhasil: konfirmasi "Absensi Berhasil - Hadir/Terlambat (X menit)" + foto bukti. Gagal lokasi: ulangi setelah pastikan GPS aktif & di area sekolah. Gagal liveness: pastikan wajah asli. Gagal mock: hubungi Admin TU.
        </Step>
        <Step step={6} title="Absen Pulang">
          Untuk absen pulang, ulangi langkah yang sama pada jam pulang hari itu.
        </Step>
      </div>
      <Callout type="info" title="Jika Internet Sekolah Terputus">
        Sistem menyimpan data scan di perangkat Anda (status "Tersimpan offline"). Saat internet kembali, data otomatis tersinkronisasi. Anda tetap mendapat konfirmasi absen berhasil.
      </Callout>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <FileText className="w-5 h-5 text-sky-600" /> Mengajukan Izin/Sakit/Dinas Luar
      </h3>
      <div className="mb-8">
        <Step step={1} title="Buka Menu Pengajuan Izin">
          Login ke portal guru. Klik menu "Pengajuan Izin". Klik "+ Ajukan Izin Baru".
        </Step>
        <Step step={2} title="Isi Form">
          Pilih Tipe Izin (Izin/Sakit/Dinas Luar/Cuti). Pilih tanggal mulai dan selesai. Tulis alasan. Upload surat bukti (PDF/JPG/PNG, maks 2 MB) - wajib untuk Sakit & Dinas Luar.
        </Step>
        <Step step={3} title="Kirim dan Tunggu">
          Klik "Kirim Pengajuan". Status: "Pending" - menunggu persetujuan Admin. Anda menerima notifikasi saat Admin menyetujui atau menolak.
        </Step>
      </div>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8 flex items-center gap-2">
        <Calendar className="w-5 h-5 text-sky-600" /> Melihat Riwayat Absensi Mandiri
      </h3>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card title="Tabel Riwayat Harian">
          Tanggal, jam datang, jam pulang, status (Hadir/Terlambat/Izin/Sakit/Alpha), foto bukti thumbnail.
        </Card>
        <Card title="Filter & Statistik">
          Filter per bulan atau per status. Statistik bulan berjalan: total hadir, terlambat, izin, alpha. Unduh riwayat pribadi sebagai PDF.
        </Card>
      </div>
    </div>
  );
}
