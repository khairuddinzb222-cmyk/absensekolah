import SectionHeader from '@/components/SectionHeader';
import { Card, Table, Callout } from '@/components/UI';
import { schoolInfo } from '@/data/specData';
import { UserCog, FileText, Calendar, Upload, MapPin } from 'lucide-react';

export default function SelfServiceSection() {
  return (
    <div>
      <SectionHeader
        number="Modul 6"
        title="Portal Mandiri Guru (Teacher Self-Service)"
        subtitle="Pengajuan izin/sakit/dinas luar dengan unggahan surat bukti, serta riwayat kehadiran real-time yang transparan."
      />

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">6.1 Pengajuan Izin/Sakit/Dinas Luar</h3>
      <p className="text-slate-600 mb-4">
        Guru dapat mengajukan izin, sakit, atau dinas luar melalui aplikasi, dilengkapi unggahan surat bukti,
        jika harus bertugas di luar radius 300 meter dari {schoolInfo.name}.
      </p>
      <Table
        headers={['Field', 'Tipe', 'Wajib']}
        rows={[
          ['Tipe Izin', 'Dropdown: Izin / Sakit / Dinas Luar / Cuti', 'Ya'],
          ['Tanggal Mulai', 'Date picker', 'Ya'],
          ['Tanggal Selesai', 'Date picker', 'Ya'],
          ['Alasan', 'Textarea', 'Ya'],
          ['Surat Bukti', 'Upload file (PDF/JPG/PNG, maks 2 MB, terkompresi otomatis)', 'Ya untuk Sakit & Dinas Luar'],
          ['Koordinat Lokasi Dinas', 'Auto-capture GPS (untuk Dinas Luar)', 'Opsional'],
        ]}
      />
      <Card icon={<FileText className="w-5 h-5" />} title="Alur Persetujuan" className="mb-4">
        <ol className="list-decimal pl-4 space-y-1">
          <li>Guru submit pengajuan → status <strong>"Pending"</strong>.</li>
          <li>Admin menerima notifikasi.</li>
          <li>Admin review → <strong>Approve/Reject</strong> + catatan.</li>
          <li>Guru menerima notifikasi hasil.</li>
          <li>Jika approved → status absensi pada tanggal terkait berubah sesuai tipe izin (otomatis, tidak perlu scan wajah).</li>
          <li>Jika Dinas Luar approved → koordinat lokasi dinas tercatat sebagai lokasi absensi alternatif.</li>
        </ol>
      </Card>

      <h3 className="text-lg font-semibold text-slate-800 mb-4 mt-8">6.2 Riwayat Kehadiran Real-Time</h3>
      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <Card icon={<Calendar className="w-5 h-5" />} title="Riwayat Harian">
          <ul className="list-disc pl-4 space-y-1">
            <li>Tabel: tanggal, jam datang, jam pulang, status, foto bukti (thumbnail).</li>
            <li>Filter per bulan, per status (hadir/terlambat/izin/alpha).</li>
          </ul>
        </Card>
        <Card title="Statistik & Export">
          <ul className="list-disc pl-4 space-y-1">
            <li>Total hadir, terlambat, izin, alpha bulan berjalan.</li>
            <li>Guru dapat unduh riwayat pribadi sebagai PDF (tanpa kop, untuk arsip pribadi).</li>
            <li>Update langsung setelah scan, tanpa refresh.</li>
          </ul>
        </Card>
      </div>
      <Callout type="info" title="Transparansi">
        Riwayat kehadiran real-time dapat dilihat langsung oleh masing-masing guru setelah login di link portal guru mereka sendiri.
      </Callout>
    </div>
  );
}
