import { useState } from 'react';
import { School, KeyRound, ArrowLeft, ScanFace, AlertCircle } from 'lucide-react';

type Props = {
  onBack: () => void;
};

export default function GuruLogin({ onBack }: Props) {
  const [nip, setNip] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!nip.trim() || !pin.trim()) {
      setError('NIP/Email dan PIN wajib diisi.');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setError('Sistem absensi sedang dalam tahap pengembangan. Hubungi Admin TU untuk kredensial aktif.');
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-cyan-50 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-700 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Dokumen
        </button>

        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          <div className="bg-gradient-to-br from-sky-500 to-cyan-500 p-6 text-white text-center">
            <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center mx-auto mb-3">
              <School className="w-8 h-8" />
            </div>
            <h1 className="text-xl font-bold">Portal Guru</h1>
            <p className="text-sm opacity-90 mt-1">Sistem Absensi Wajah</p>
            <p className="text-xs opacity-75 mt-0.5">SMP Kartika XIV-1 Banda Aceh</p>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">NIP atau Email</label>
              <input
                type="text"
                value={nip}
                onChange={(e) => setNip(e.target.value)}
                placeholder="Masukkan NIP atau Email"
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none transition-all text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">PIN (6 digit)</label>
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="Masukkan PIN 6 digit"
                maxLength={6}
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none transition-all text-sm tracking-widest"
              />
            </div>

            {error && (
              <div className="flex items-start gap-2 text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-lg p-3">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-sky-500 to-cyan-500 text-white font-semibold py-2.5 rounded-lg hover:from-sky-600 hover:to-cyan-600 transition-all disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading ? (
                <span className="animate-pulse">Memproses...</span>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  Masuk
                </>
              )}
            </button>
          </form>

          <div className="px-6 pb-6">
            <div className="bg-sky-50 border border-sky-100 rounded-lg p-3 flex items-start gap-2">
              <ScanFace className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
              <p className="text-xs text-sky-700 leading-relaxed">
                Setelah login, guru dapat mendaftarkan wajah, melakukan scan absensi harian (dalam radius 300 meter sekolah),
                mengajukan izin, dan melihat riwayat kehadiran.
              </p>
            </div>
          </div>
        </div>

        <p className="text-center text-xs text-slate-400 mt-4">
          www://smpkartika.my.id/guru
        </p>
      </div>
    </div>
  );
}
