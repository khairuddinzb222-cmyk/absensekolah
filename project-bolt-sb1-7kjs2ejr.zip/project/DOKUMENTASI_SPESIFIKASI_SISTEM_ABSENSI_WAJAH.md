# DOKUMEN SPESIFIKASI KEBUTUHAN SISTEM (SRS), SOP, & BUKU PANDUAN PENGUNA
## Aplikasi Absensi Harian Guru Berbasis Scan Wajah (Face Recognition)
### SMP Kartika XIV-1 Banda Aceh

---

| Item | Keterangan |
|---|---|
| **Nama Sistem** | Sistem Absensi Harian Guru Berbasis Pengenalan Wajah (Face Recognition Attendance System) |
| **Instansi Pengguna** | SMP Kartika XIV-1 Banda Aceh |
| **Alamat Sekolah** | Jl. Nyak Adam Kamil II, Peuniti, Kec. Baiturrahman, Kota Banda Aceh |
| **Versi Dokumen** | 1.0 |
| **Klasifikasi Dokumen** | Resmi — Siap Distribusi ke Tim Developer & Pihak Sekolah |
| **Tipe Dokumen** | Software Requirements Specification (SRS) + Standard Operating Procedure (SOP) + User Manual |

---

# BAGIAN I — SPESIFIKASI KEBUTUHAN SISTEM (SYSTEM REQUIREMENTS)

---

## 1. FITUR KEAMANAN AKSES & PEMISAHAN LINK LOGIN (URL SEPARATION)

### 1.1 Pemisahan Link Akses (URL Separation)

Sistem wajib mengimplementasikan pemisahan jalur akses (URL) secara tegas antara portal Guru dan portal Admin untuk mencegah pencarian jalur admin oleh pihak yang tidak berwenang dan memperkecil permukaan serangan (attack surface).

| Portal | URL Akses | Keterangan |
|---|---|---|
| Portal Guru | `https://smpkartika14-1.sch.id` | URL publik, dapat diakses dari jaringan mana pun. |
| Portal Admin | `https://admin.smpkartika14-1.sch.id` | Subdomain khusus, tidak diindeks mesin pencari (noindex), dilindungi IP Whitelisting. |

**Persyaratan Teknis:**
- Subdomain admin tidak boleh tampil di hasil pencarian Google (meta `robots` = `noindex, nofollow`).
- Halaman utama subdomain admin tidak menampilkan form login yang dapat ditebak; gunakan halaman perantara (gateway page) atau endpoint tersembunyi.
- Sertifikat SSL/TLS terpisah untuk setiap subdomain (SAN certificate atau wildcard certificate `*.smpkartika14-1.sch.id`).
- Routing berbasis reverse proxy (Nginx/Cloudflare) yang memisahkan trafik guru dan admin pada layer infrastruktur, bukan hanya pada layer aplikasi.

### 1.2 Jalur Aman Admin (Network Security)

**Enkripsi SSL/HTTPS:**
- Seluruh komunikasi wajib menggunakan HTTPS dengan TLS 1.2/1.3. HTTP wajib di-redirect otomatis ke HTTPS (HSTS header aktif).
- Sertifikat dari otoritas terpercaya (Let's Encrypt / komersial), auto-renewal.
- Cipher suite mengikuti rekomendasi terkini (forward secrecy, disabled SSLv3/TLS 1.0/1.1).

**IP Whitelisting (Pembatasan Akses Halaman Admin):**
- Portal admin hanya dapat diakses dari rentang IP jaringan internal sekolah (Wi-Fi/LAN kantor, jaringan TU, dan jaringan Kepala Sekolah).
- Implementasi pada layer reverse proxy (Nginx `allow/deny`) atau Web Application Firewall (WAF), bukan hanya pada layer aplikasi.
- Daftar IP whitelist dapat diperbarui oleh Super Admin melalui panel khusus (dengan audit trail).
- Mekanisme fallback darurat: akses sementara dari IP eksternal dapat diizinkan via token one-time yang dikirim ke email Kepala Sekolah, berlaku 1 jam, tercatat di audit trail.

**Proteksi Tambahan Jalur Admin:**
- Rate limiting pada endpoint login admin (maksimum 5 percobaan per menit per IP).
- CAPTCHA setelah 3 percobaan gagal.
- Notifikasi email ke Kepala Sekolah setiap kali login admin berhasil dari IP baru.
- Session timeout admin: 15 menit idle, wajib re-authentication.
- Two-Factor Authentication (2FA) opsional untuk admin (TOTP / Google Authenticator).

### 1.3 Gerbang Login Guru

**Metode Login:** NIP atau Email + PIN (6 digit).

| Parameter | Spesifikasi |
|---|---|
| Identifier | NIP (prioritas) atau Email resmi guru |
| Kredensial | PIN 6 digit numerik |
| PIN Awal | Dibuat oleh admin saat pendaftaran guru; guru wajib mengganti PIN saat login pertama (force change PIN) |
| Kebijakan PIN | Tidak boleh berurutan (123456), tidak boleh tanggal lahir, tidak boleh berulang (111111) |
| Percobaan Gagal | Akun terkunci sementara 15 menit setelah 5 kali gagal; notifikasi ke admin |
| Token Sesi | JWT berumur 12 jam, refresh token opsional |

**Catatan Keamanan:** PIN guru bersifat ringkas karena portal guru hanya menampilkan riwayat absensi pribadi dan pengajuan izin — tidak ada akses ke data guru lain. Aksi sensitif (reset PIN, pendaftaran wajah) tetap memerlukan konfirmasi PIN ulang.

### 1.4 Gerbang Login Admin

**Metode Login:** Username + Password Kompleks + (opsional) 2FA.

| Parameter | Spesifikasi |
|---|---|
| Username | Minimal 5 karakter, unik, case-sensitive |
| Password | Minimal 12 karakter, wajib mengandung huruf besar, huruf kecil, angka, dan simbol |
| Riwayat Password | Tidak boleh sama dengan 5 password terakhir |
| Masa Berlaku Password | 90 hari, wajib diganti |
| Kunci Akun | 5 kali gagal → kunci 30 menit + notifikasi ke Kepala Sekolah |
| 2FA | Opsional, direkomendasikan (TOTP) |
| Sesi | 15 menit idle timeout, JWT + fingerprint perangkat |

**Peran Admin (Role-Based Access Control):**
- **Super Admin:** akses penuh termasuk kelola admin lain, IP whitelist, reset kredensial admin.
- **Admin TU:** kelola data guru, jadwal, laporan, override absen.
- **Kepala Sekolah (read-only):** lihat laporan, grafik, audit trail, tanpa hak edit.

---

## 2. FITUR PENDAFTARAN WAJAH & VALIDASI (FACE ENROLLMENT & VALIDATION)

### 2.1 Pendaftaran Fleksibel (Face Enrollment)

Guru dapat melakukan pendaftaran wajah pertama kali dari mana saja (rumah, kafe, mana pun) melalui aplikasi portal guru. Tidak ada batasan geofencing pada tahap enrollment.

**Alur Pendaftaran:**
1. Guru login di portal guru.
2. Guru membuka menu "Daftar Wajah" → kamera depan perangkat aktif.
3. Sistem memberikan panduan framing wajah (oval guide), instruksi posisi (hadap lurus, pencahayaan cukup, tidak memakai masker/kacamata gelap).
4. Sistem menangkap **3 sampai 5 frame** dari sudut sedikit berbeda (hadap depan, sedikit menoleh kiri, sedikit menoleh kanan) untuk meningkatkan akurasi.
5. Sistem menjalankan **liveness check mini** saat enrollment (kedipkan mata, buka mulut) untuk mencegah foto statis sejak tahap pendaftaran.
6. Frame wajah dikonversi menjadi **face embedding (vektor 128/512 dimensi)** menggunakan model face recognition (FaceNet / ArcFace / DeepFace) di sisi server.
7. Status wajah guru berubah menjadi **"Pending"** dan menunggu validasi admin.

**Spesifikasi Teknis Enrollment:**
- Model face recognition: FaceNet (512-d) atau ArcFace (512-d), akurasi ≥ 99.5% pada LFW.
- Threshold kemiripan (cosine similarity): ≥ 0.6 untuk match, dapat dikalibrasi admin.
- Anti-spoofing enrollment: liveness detection berbasis kedip mata + analisis tekstur (foto cetak memiliki pola tekstur berbeda dari wajah hidup).
- Penyimpanan: **hanya vektor embedding** disimpan di server, BUKAN foto mentah wajah (privasi & efisiensi storage). Foto mentah dapat dihapus setelah embedding terbentuk, kecuali satu foto referensi untuk verifikasi admin.

### 2.2 Validasi Admin (Approval Workflow)

Wajah yang baru didaftarkan oleh guru berstatus **"Pending"** dan **tidak dapat digunakan untuk absensi** sampai Admin melakukan verifikasi manual.

**Alur Validasi di Panel Admin:**
1. Admin membuka menu "Persetujuan Wajah" di panel admin.
2. Sistem menampilkan daftar guru berstatus Pending, lengkap dengan:
   - Foto referensi wajah hasil enrollment.
   - Foto profil resmi guru (dari data Dapodik / foto yang diunggah admin saat pendaftaran).
   - Data identitas (NIP, nama, jabatan).
3. Admin membandingkan kedua foto secara visual untuk memastikan kesesuaian identitas.
4. Admin memilih:
   - **Approve** → status wajah berubah "Active", guru dapat melakukan absensi.
   - **Reject** → status berubah "Rejected" + wajib mencantumkan alasan (catatan). Guru menerima notifikasi dan diminta mendaftar ulang.
5. Setiap aksi approve/reject tercatat di audit trail (admin siapa, kapan, guru siapa).

**Tujuan:** Mencegah kecurangan pendaftaran wajah orang lain (teman/keluarga) yang dapat dimanfaatkan untuk absensi di luar lokasi.

### 2.3 Reset Face ID

Admin memiliki tombol **"Reset Face ID"** pada detail setiap guru untuk:
- Menghapus embedding wajah yang ada.
- Mengubah status wajah guru menjadi "Not Enrolled".
- Mengirim notifikasi otomatis ke guru (WhatsApp/Email) berisi instruksi pendaftaran ulang.
- Mencatat aktivitas reset di audit trail.

**Skenario Penggunaan:**
- Kendala pemindaian berulang (perubahan wajah signifikan, operasi, cedera).
- Dugaan kebocoran/penyalahgunaan data wajah.
- Guru keluar/mutasi dan data wajah perlu dibersihkan.

### 2.4 Kompresi Gambar Otomatis

Sistem otomatis memperkecil ukuran file foto wajah hasil enrollment dan dokumen izin sebelum disimpan ke server.

| Parameter | Spesifikasi |
|---|---|
| Format input | JPEG, PNG, WebP |
| Format output | WebP (foto wajah), JPEG (dokumen izin) |
| Resolusi target foto wajah | Maksimum 800×800 px (cukup untuk face embedding) |
| Resolusi target dokumen izin | Maksimum 1500×2000 px (terbaca jelas) |
| Ukuran file foto wajah | ≤ 150 KB setelah kompresi |
| Ukuran file dokumen izin | ≤ 500 KB setelah kompresi |
| Algoritma | Kompresi lossy adaptif (quality 80), resize via Lanczos resampling |
| Kualitas wajah | Tetap terdeteksi dengan skor face detection ≥ 0.9 setelah kompresi |

**Implementasi:** Kompresi berjalan di sisi server (Sharp/libvips untuk Node, Pillow untuk Python) setelah unggahan, sebelum penyimpanan ke object storage / database. Opsi kompresi sisi klien (canvas API) untuk mengurangi bandwidth unggah.

---

## 3. FITUR UTAMA ABSENSI & PEMBATASAN JARAK (CORE FEATURES & GEOFENCING)

### 3.1 Absen Berbasis Lokasi (Radius 300 Meter)

Untuk scan wajah kehadiran harian (jam datang dan jam pulang), sistem wajib mengunci koordinat target di **SMP Kartika XIV-1 Banda Aceh**.

| Parameter | Nilai |
|---|---|
| Nama Lokasi | SMP Kartika XIV-1 Banda Aceh |
| Alamat | Jl. Nyak Adam Kamil II, Peuniti, Kec. Baiturrahman, Kota Banda Aceh |
| Latitude (perkiraan) | 5.5483° LS *(koordinat final dikunci admin via Google Maps)* |
| Longitude (perkiraan) | 95.3237° BT *(koordinat final dikunci admin via Google Maps)* |
| Radius Geofence | 300 meter |
| Rumus Jarak | Haversine formula (akurasi ±1 meter pada jarak pendek) |

**Mekanisme Penguncian:**
1. Saat guru membuka halaman absensi, perangkat mengambil koordinat GPS/Wi-Fi saat ini.
2. Sistem menghitung jarak (Haversine) antara posisi guru dan koordinat sekolah.
3. Jika jarak ≤ 300 meter → tombol "Scan Wajah" aktif.
4. Jika jarak > 300 meter → tombol "Scan Wajah" **terkunci otomatis**, tampilkan pesan: "Anda berada di luar area sekolah (jarak X meter). Absensi hanya dapat dilakukan di dalam radius 300 meter SMP Kartika XIV-1 Banda Aceh."
5. Sistem menampilkan peta mini (Google Maps) dengan marker sekolah, lingkaran radius 300 meter, dan titik posisi guru saat ini.

### 3.2 Teknologi Pendeteksi Lokasi & Anti-Kecurangan

**Multi-Source Location (Akurasi Tinggi):**
- **GPS** (satelit) — sumber utama, akurasi 3–5 meter di luar ruangan.
- **GLONASS** — sumber tambahan, meningkatkan akurasi di area padat.
- **Wi-Fi Positioning** — triangulasi sinyal Wi-Fi sekitar, akurasi 10–20 meter di dalam ruangan.
- **Cell Tower Triangulation** — fallback ketika GPS lemah, akurasi 50–500 meter.
- Perangkat wajib mengaktifkan "Mode Akurasi Tinggi" (High Accuracy) pada pengaturan lokasi.

**Anti-Mock Location (Anti Fake GPS):**

Sistem wajib mendeteksi dan **menolak absensi** jika guru menggunakan aplikasi Fake GPS, memanipulasi koordinat, atau mengaktifkan Developer Options.

| Lapisan Deteksi | Metode |
|---|---|
| 1. API Browser | `navigator.geolocation` dengan `enableHighAccuracy: true`. Koordinat dengan akurasi > 100 meter ditandai mencurigakan. |
| 2. Flag Mock Location | Deteksi `isMockProvider` / `isFromMockProvider` pada Android via Web API atau wrapper native. |
| 3. Developer Options | Deteksi aktifnya USB Debugging / Developer Options (via permission check atau behavior fingerprinting). |
| 4. Konsistensi Sensor | Cross-check koordinat GPS vs Wi-Fi positioning vs IP geolocation. Jika selisih signifikan → flag mencurigakan. |
| 5. Timestamp & Movement | Analisis pola pergerakan: lonjakan koordinat tidak realistis (teleportasi) → ditolak. |
| 6. Altitude Check | GPS mock sering tidak menyertakan altitude realistis; cross-check altitude dengan topografi Banda Aceh. |
| 7. Native App Wrapper | Jika dikembangkan sebagai PWA/hybrid, gunakan plugin native (cordova-plugin-advanced-geolocation / Capacitor Geolocation) untuk akses flag mock yang lebih dalam. |

**Tindakan Saat Terdeteksi Manipulasi:**
- Absensi **ditolak otomatis**.
- Sistem mencatat upaya manipulasi di log keamanan (guru siapa, waktu, jenis manipulasi terdeteksi).
- Notifikasi otomatis ke admin dan Kepala Sekolah.
- Guru melihat pesan: "Sistem mendeteksi potensi manipulasi lokasi. Absensi ditolak. Silakan hubungi Admin TU."

### 3.3 Deteksi Keaslian Wajah (Liveness Detection)

Algoritma AI pendeteksi gerakan mikro wajah agar absensi tidak bisa dimanipulasi menggunakan foto cetak atau video dari HP.

| Teknik | Deskripsi |
|---|---|
| Active Liveness (Challenge-Response) | Sistem memberikan instruksi acak: "Kedipkan mata 2 kali", "Tersenyum", "Putar wajah ke kiri", "Buka mulut". Wajib dilakukan dalam 5 detik. |
| Passive Liveness (Texture Analysis) | Analisis tekstur wajah: foto cetak memiliki pola moiré/refleksi kertas yang berbeda dari kulit hidup. Model CNN terlatih membedakan live vs spoof. |
| Depth Detection | (Jika perangkat mendukung) estimasi kedalaman wajah — foto datar tidak memiliki depth map. |
| Micro-Movement Analysis | Deteksi gerakan mikro tidak disengaja (nafas, kedip spontan, pergerakan pupil) dalam frame berurutan. |
| Infrared/IR (opsional) | Pada perangkat dengan sensor IR, verifikasi wajah hidup memancarkan panas. |

**Threshold:** Skor liveness ≥ 0.85 (dapat dikalibrasi admin). Di bawah threshold → absensi ditolak dengan pesan "Verifikasi keaslian wajah gagal. Pastikan Anda tidak menggunakan foto/video."

### 3.4 Kecepatan Pemindaian

| Parameter | Target |
|---|---|
| Waktu pemrosesan scan wajah per orang | < 2 detik (end-to-end: capture → embedding → match → record) |
| Waktu capture frame | < 500 ms |
| Waktu generate embedding | < 800 ms (server-side, GPU opsional) |
| Waktu match (1:N atau 1:1) | < 500 ms (1:1 untuk guru yang login, 1:N opsional untuk kiosk) |
| Throughput | Mendukung 50+ guru dalam window 15 menit (jam puncak pagi) |

**Optimasi:**
- Face embedding guru di-cache di memory (Redis) untuk matching cepat.
- Model face recognition dioptimasi (TensorRT / ONNX Runtime) untuk inferensi cepat.
- Koneksi API lokasi & face recognition di-pipeline secara paralel.

### 3.5 Mode Offline Sementara

Kemampuan menyimpan data scan lokal di perangkat jika koneksi internet sekolah terputus, lalu sinkronisasi otomatis ke cloud saat internet kembali.

**Mekanisme:**
1. Saat scan wajah berhasil tetapi koneksi server gagal → data absensi (timestamp, koordinat, embedding match result, foto bukti) disimpan di **IndexedDB / localStorage** perangkat.
2. Data offline ditandai status "Pending Sync".
3. Background service worker memantau koneksi; saat online, data di-sync ke server secara berurutan (FIFO).
4. Server melakukan **idempotency check** (berdasarkan hash timestamp + user_id) untuk mencegah duplikasi.
5. Setelah sync berhasil, data lokal ditandai "Synced" dan dapat dihapus setelah 7 hari.
6. Guru melihat badge status: "Tersimpan offline — menunggu sinkronisasi".

**Batasan:**
- Mode offline hanya untuk menyimpan hasil scan yang **sudah lolos verifikasi lokal** (lokasi + liveness). Tidak boleh digunakan untuk melewati geofence.
- Maksimal 5 absensi offline tersimpan per perangkat (anti penimbunan).
- Data offline terenkripsi (AES) di perangkat.

---

## 4. FITUR MANAJEMEN WAKTU & TOLERANSI

### 4.1 Kustomisasi Jam Masuk & Pulang Harian (Senin–Sabtu)

Admin dapat mengedit secara manual jadwal jam masuk dan jam pulang yang berbeda untuk setiap hari dari Senin sampai Sabtu.

**Struktur Data Jadwal Mingguan:**

| Hari | Jam Masuk | Toleransi Terlambat | Jam Pulang | Keterangan |
|---|---|---|---|---|
| Senin | 07.15 | 15 menit | 15.30 | Hari kerja penuh |
| Selasa | 07.15 | 15 menit | 15.30 | Hari kerja penuh |
| Rabu | 07.15 | 15 menit | 15.30 | Hari kerja penuh |
| Kamis | 07.15 | 15 menit | 15.30 | Hari kerja penuh |
| Jumat | 07.15 | 15 menit | 11.00 | Pulang lebih cepat |
| Sabtu | 07.30 | 15 menit | 12.00 | Setengah hari |
| Minggu | — | — | — | Libur |

**Catatan:** Nilai di atas adalah contoh. Admin dapat mengubah kapan saja melalui panel. Jadwal disimpan per hari, dengan dukungan beberapa set jadwal (misal jadwal khusus bulan Ramadhan).

**Fitur Tambahan:**
- **Jadwal Khusus/Seasonal:** Admin dapat membuat set jadwal khusus (misal "Jadwal Ramadhan", "Jadwal Ujian", "Jadwal Libur Semester") dengan rentang tanggal efektif.
- **Penanggalan Libur Nasional:** Integrasi kalender libur nasional Indonesia (otomatis atau manual input).
- **Preview Jadwal:** Tampilan kalender mingguan/bulanan yang menampilkan jadwal aktif.

### 4.2 Toleransi Keterlambatan

Pengaturan menit toleransi keterlambatan harian yang dapat dikustomisasi secara dinamis oleh admin.

| Parameter | Spesifikasi |
|---|---|
| Default toleransi | 15 menit |
| Rentang | 0–60 menit, per hari |
| Logika | Absen di dalam toleransi → status "Tepat Waktu". Absen setelah toleransi → status "Terlambat" dengan menit keterlambatan tercatat. |
| Dinamis | Dapat diubah per hari, per musim (Ramadhan), atau per kebijakan khusus. |

### 4.3 Pengaturan Koordinat Sekolah

Fitur bagi admin untuk mengunci atau menyesuaikan titik Latitude dan Longitude SMP Kartika XIV-1 Banda Aceh serta mengunci batas radius.

**Antarmuka Admin:**
- Peta Google Maps interaktif dengan marker draggable.
- Admin menyeret marker ke titik pusat sekolah yang akurat.
- Sistem menampilkan lingkaran radius 300 meter (dapat diubah, tapi default terkunci 300 m).
- Input manual Latitude/Longitude untuk presisi.
- Tombol "Gunakan Lokasi Saya" untuk kalibrasi dari posisi admin di lokasi.
- Preview daftar guru yang sedang berada di dalam/luar radius (opsional).

**Penguncian:**
- Perubahan koordinat hanya bisa dilakukan oleh Super Admin atau Admin TU.
- Setiap perubahan tercatat di audit trail.
- Radius default 300 meter dapat diubah hanya dengan konfirmasi ganda + alasan.

### 4.4 Jadwal Kerja & Shifting

Pencatatan otomatis untuk berbagai skenario kerja guru:

| Tipe Guru | Aturan |
|---|---|
| Guru PNS (jam penuh) | Jam masuk–pulang standar Senin–Sabtu. |
| Guru Honorer (harian) | Jam kerja fleksibel, dihitung per jam kerja. Absen datang + pulang wajib untuk perhitungan honor harian. |
| Guru Piket | Jadwal piket pagi/siang/sore, dapat berbeda dari jam standar. Sistem mendeteksi berdasarkan jadwal piket yang diinput admin. |
| Guru Lembur | Pencatatan jam lembur otomatis jika scan pulang melebihi jam pulang standar + lebih dari 1 jam. Admin dapat approve/reject lembur. |
| Guru Tidak Penuh (jam mengajar terbatas) | Jadwal khusus per guru, admin input jadwal mengajar. Absensi dihitung berdasarkan jam mengajar aktual. |

**Implementasi:** Tabel `teacher_shift` dengan relasi ke `teacher` dan `weekly_schedule`, mendukung multiple shift per guru.

---

## 5. INTEGRASI & NOTIFIKASI OTOMATIS

### 5.1 Notifikasi Gateway (WhatsApp & Email)

Sinkronisasi otomatis dengan WhatsApp Gateway atau Email untuk mengirim laporan kehadiran harian.

| Channel | Penerima | Konten | Waktu |
|---|---|---|---|
| WhatsApp | Kepala Sekolah | Rekap singkat: total hadir, terlambat, izin, alpha | 08.00 & 16.00 harian |
| WhatsApp | Admin TU | Detail rekap + daftar guru yang belum absen | 08.30 & 16.30 harian |
| Email | Kepala Sekolah & TU | Laporan harian lengkap (PDF terlampir) | 17.00 harian |
| WhatsApp | Guru (individu) | Konfirmasi absensi berhasil/gagal + status tepat waktu/terlambat | Real-time setelah scan |
| WhatsApp | Guru (individu) | Pengingat jika belum absen sampai jam masuk + toleransi | 10 menit setelah batas toleransi |

**Teknologi:**
- WhatsApp Gateway via API pihak ketiga (Wablas, Fonnte, Whacenter) atau WhatsApp Business API resmi.
- Email via SMTP (Gmail Workspace / layanan transactional seperti SendGrid).
- Template pesan dapat dikustomisasi admin.
- Retry otomatis 3 kali jika pengiriman gagal, lalu log error.

### 5.2 Integrasi Penggajian (Payroll Integration)

Sistem dapat mengekspor rekap keterlambatan dan jumlah alpha yang terintegrasi dengan rumus pemotongan tunjangan atau perhitungan gaji guru harian.

**Fitur:**
- Ekspor rekap bulanan per guru: total hadir, total terlambat (menit), total alpha (hari), total izin/sakit.
- Rumus pemotongan tunjangan dapat dikonfigurasi admin:
  - Contoh: `Potongan = (Menit terlambat × Rp X) + (Hari alpha × Rp Y)`.
  - Contoh guru honorer: `Honor Harian = (Jam hadir × Rp Z) − Potongan`.
- Ekspor format Excel/CSV siap import ke sistem payroll eksternal.
- Template rumus fleksibel (admin input koefisien).
- Preview perhitungan sebelum ekspor.

### 5.3 Sinkronisasi Dapodik

Format ekspor data guru dan kehadiran disesuaikan dengan standar Dapodik.

| Data | Format Dapodik |
|---|---|
| Data Guru | NIP, Nama, NIK, Tempat/Tanggal Lahir, Jenis Kelamin, Status Kepegawaian, Mata Pelajaran, Pendidikan |
| Kehadiran Bulanan | Per guru: total hadir, sakit, izin, alpha, per bulan |
| Ekspor | CSV/Excel sesuai template Dapodik (kolom & urutan sesuai standar) |

**Implementasi:** Modul ekspor khusus dengan mapping kolom ke template Dapodik terbaru. Admin dapat memilih bulan dan tahun, lalu unduh file siap upload ke Dapodik.

---

## 6. PORTAL MANDIRI GURU (TEACHER SELF-SERVICE)

### 6.1 Pengajuan Izin/Sakit/Dinas Luar

Guru dapat mengajukan izin, sakit, atau dinas luar melalui aplikasi, dilengkapi unggahan surat bukti, jika harus bertugas di luar radius 300 meter.

**Form Pengajuan:**

| Field | Tipe | Wajib |
|---|---|---|
| Tipe Izin | Dropdown: Izin / Sakit / Dinas Luar / Cuti | Ya |
| Tanggal Mulai | Date picker | Ya |
| Tanggal Selesai | Date picker | Ya |
| Alasan | Textarea | Ya |
| Surat Bukti | Upload file (PDF/JPG/PNG, maks 2 MB, terkompresi otomatis) | Ya untuk Sakit & Dinas Luar |
| Koordinat Lokasi Dinas | Auto-capture GPS (untuk Dinas Luar) | Opsional |

**Alur Persetujuan:**
1. Guru submit pengajuan → status "Pending".
2. Admin menerima notifikasi.
3. Admin review → Approve/Reject + catatan.
4. Guru menerima notifikasi hasil.
5. Jika approved → status absensi pada tanggal terkait berubah sesuai tipe izin (otomatis, tidak perlu scan wajah).
6. Jika Dinas Luar approved → koordinat lokasi dinas tercatat sebagai lokasi absensi alternatif (opsional, sekali jalan).

### 6.2 Riwayat Kehadiran Real-Time

| Fitur | Spesifikasi |
|---|---|
| Riwayat harian | Tabel: tanggal, jam datang, jam pulang, status, foto bukti (thumbnail) |
| Filter | Per bulan, per status (hadir/terlambat/izin/alpha) |
| Statistik pribadi | Total hadir, terlambat, izin, alpha bulan berjalan |
| Export | Guru dapat unduh riwayat pribadi sebagai PDF (tanpa kop, untuk arsip pribadi) |
| Real-time | Update langsung setelah scan, tanpa refresh |

---

## 7. DASHBOARD & PANEL KONTROL ADMIN (ADMIN MANAGEMENT PANEL)

### 7.1 Pengaturan Jadwal Mingguan Manual

Halaman khusus bagi admin untuk mengedit jadwal jam masuk/pulang Senin–Sabtu.

**Antarmuka:**
- Tabel 7 baris (Senin–Sabtu) × kolom (Jam Masuk, Toleransi, Jam Pulang, Status Aktif).
- Time picker per sel.
- Tombol "Simpan Perubahan" dengan konfirmasi.
- Preview perubahan sebelum simpan.
- Riwayat perubahan jadwal (audit trail).

### 7.2 Kustomisasi Dokumen Laporan (Kop & Logo)

Fitur bagi admin untuk mengunggah logo sekolah dan mengisi teks Kop Surat resmi.

| Elemen | Spesifikasi |
|---|---|
| Logo Sekolah | Upload PNG/JPG transparan, maks 1 MB, auto-resize ke 200×200 px |
| Nama Sekolah | Text input (contoh: "SMP KARTIKA XIV-1 BANDA ACEH") |
| Alamat Sekolah | Text input multiline |
| Nomor Telepon/Email/Fax | Text input |
| Teks Kop | Otomatis tersusun di header laporan |

**Preview:** Admin melihat preview laporan dengan kop sebelum menyimpan.

### 7.3 Tanda Tangan Kepala Sekolah (Legalitas)

| Elemen | Spesifikasi |
|---|---|
| Nama Kepala Sekolah | Text input |
| NIP Kepala Sekolah | Text input |
| Scan Tanda Tangan | Upload PNG transparan, maks 500 KB, auto-resize |
| Stempel Digital Sekolah | Upload PNG transparan, maks 500 KB |
| Posisi di Laporan | Footer kanan, di bawah tabel absensi |
| Tanggal Otomatis | Tanggal cetak otomatis terisi |

**Hasil:** Setiap laporan cetak siap legal secara administrasi — memiliki kop, logo, tanda tangan, stempel, dan tanggal.

### 7.4 Manajemen Data Guru Manual

Hak akses penuh bagi admin untuk mengelola data guru.

**Operasi:**

| Operasi | Metode |
|---|---|
| Tambah Manual | Form satu per satu: NIP, Nama, Email, No. HP, Jabatan, Status (PNS/Honorer), PIN awal, Foto profil |
| Tambah Massal | Upload Excel (template disediakan), sistem validasi & preview sebelum import |
| Edit Profil | Edit semua field kecuali NIP (NIP immutable setelah dibuat) |
| Hapus Guru | Soft delete (status "Tidak Aktif"), data tetap tersimpan untuk arsip. Hard delete hanya untuk Super Admin dengan konfirmasi ganda. |
| Aktifkan/Nonaktifkan | Toggle status aktif tanpa menghapus data |

**Template Excel Massal:** Disediakan tombol "Unduh Template" dengan kolom: NIP, Nama, Email, No. HP, Jabatan, Status Kepegawaian, PIN Awal.

### 7.5 Reset Kredensial Guru

Fitur khusus admin untuk melihat/mereset username dan password guru.

| Operasi | Spesifikasi |
|---|---|
| Lihat Username | Admin dapat melihat username guru (read-only) |
| Reset PIN | Admin generate PIN baru 6 digit acak → tampilkan sekali → kirim ke guru via WhatsApp/Email |
| Reset Password (jika guru punya password) | Generate password sementara → wajib ganti saat login berikutnya |
| Force Logout | Admin dapat memaksa logout semua sesi guru (jika dugaan akun dibajak) |
| Audit | Setiap reset tercatat: admin siapa, kapan, guru siapa |

### 7.6 Override Status Absen

Fitur bagi admin untuk mengubah status kehadiran manual disertai catatan log.

**Skenario:** Guru dinas mendadak, tidak sempat pengajuan izin via aplikasi, admin ubah status dari "Alpha" menjadi "Dinas Luar".

**Antarmuka:**
- Pada detail absensi guru per tanggal, admin klik "Override Status".
- Pilih status baru: Hadir / Terlambat / Izin / Sakit / Dinas Luar / Alpha.
- Wajib isi catatan/alasan (min. 10 karakter).
- Sistem mencatat: admin siapa, waktu, status lama → status baru, catatan.
- Override tidak dapat dilakukan oleh admin pada absensi dirinya sendiri (anti self-deal).

### 7.7 Histori Log Admin (Audit Trail)

Rekam jejak digital otomatis yang mencatat aktivitas admin secara mendetail.

| Aktivitas Tercatat | Field Log |
|---|---|
| Login/Logout admin | Timestamp, admin ID, IP, device |
| Edit jadwal | Timestamp, admin ID, perubahan lama→baru |
| Approve/Reject wajah | Timestamp, admin ID, guru ID, aksi |
| Reset Face ID | Timestamp, admin ID, guru ID |
| Reset kredensial | Timestamp, admin ID, guru ID, tipe reset |
| Tambah/edit/hapus guru | Timestamp, admin ID, guru ID, aksi |
| Override absen | Timestamp, admin ID, guru ID, status lama→baru, catatan |
| Edit koordinat sekolah | Timestamp, admin ID, koordinat lama→baru |
| Edit kop/logo/ttd | Timestamp, admin ID, elemen yang diubah |
| Perubahan IP whitelist | Timestamp, admin ID, IP lama→baru |

**Penyimpanan:** Log immutable (append-only), retensi minimal 2 tahun, dapat di-export. Hanya Super Admin yang dapat melihat audit trail penuh; Admin TU melihat log aktivitasnya sendiri.

### 7.8 Laporan & Grafik

| Laporan | Format |
|---|---|
| Harian | Tabel per guru: jam datang, jam pulang, status, foto bukti. Kop + logo + ttd. |
| Mingguan | Rekap per guru: total hadir, terlambat, izin, alpha. Grafik bar. |
| Bulanan | Matrix guru × tanggal, status per hari. Grafik pie (distribusi status). Grafik line (tren kehadiran). |
| Ekspor | Excel (.xlsx) dan PDF (dengan kop, logo, ttd, stempel) |
| Filter | Per guru, per tanggal, per status, per jabatan |
| Rekap Keterlambatan | Total menit terlambat per guru per bulan (untuk payroll) |

---

# BAGIAN II — ALUR KERJA (WORKFLOW) & SOP SINGKAT

---

## 8. ALUR KERJA & SOP

### 8.1 SOP Pendaftaran Guru Baru & Enrollment Wajah

```
[Guru Baru Didaftarkan Admin]
        │
        ▼
[Admin input data guru: NIP, Nama, Email, PIN awal]
        │
        ▼
[Sistem kirim kredensial ke guru via WhatsApp/Email]
        │
        ▼
[Guru login pertama di portal guru (NIP/Email + PIN)]
        │
        ▼
[Sistem paksa ganti PIN]
        │
        ▼
[Guru buka menu "Daftar Wajah"]
        │
        ▼
[Guru lakukan Face Enrollment (dari mana saja)]
   - 3-5 frame dari sudut berbeda
   - Liveness check mini (kedip mata)
        │
        ▼
[Sistem generate face embedding → simpan ke server]
        │
        ▼
[Status wajah = "Pending"]
        │
        ▼
[Notifikasi ke Admin: "Ada pendaftaran wajah menunggu validasi"]
        │
        ▼
[Admin buka menu "Persetujuan Wajah"]
   - Bandingkan foto enrollment vs foto profil resmi
        │
        ├──[Approve]──► Status = "Active" → Guru dapat absen
        │
        └──[Reject + alasan]──► Notifikasi ke guru → Daftar ulang
```

### 8.2 SOP Absensi Harian (Scan Wajah Datang/Pulang)

```
[Guru tiba di sekolah (dalam radius 300 m)]
        │
        ▼
[Guru buka portal guru, login]
        │
        ▼
[Guru klik "Absen Sekarang"]
        │
        ▼
[Sistem cek lokasi (multi-source: GPS+GLONASS+Wi-Fi+Cell)]
        │
        ├──[Di luar 300 m]──► Tombol scan terkunci + pesan
        │
        └──[Di dalam 300 m]
                │
                ▼
        [Sistem cek Anti-Mock Location]
                │
                ├──[Mock terdeteksi]──► Absensi ditolak + log + notifikasi admin
                │
                └──[Lokasi asli]
                        │
                        ▼
                [Sistem cek jam kerja hari ini (Senin-Sabtu)]
                        │
                        ├──[Di luar jam absen]──► Pesan "Belum dalam jam absen"
                        │
                        └──[Dalam jam absen]
                                │
                                ▼
                        [Kamera aktif → Capture wajah]
                                │
                                ▼
                        [Liveness Detection (challenge + texture)]
                                │
                                ├──[Gagal liveness]──► Absensi ditolak + pesan
                                │
                                └──[Lolos liveness]
                                        │
                                        ▼
                                [Generate embedding → Match dengan embedding tersimpan]
                                        │
                                        ├──[No match]──► Absensi ditolak + pesan
                                        │
                                        └──[Match (cosine ≥ 0.6)]
                                                │
                                                ▼
                                        [Rekam absensi: timestamp, koordinat, status]
                                                │
                                                ├──[Online]──► Simpan ke cloud
                                                │
                                                └──[Offline]──► Simpan lokal → Sync saat online
                                                        │
                                                        ▼
                                        [Notifikasi ke guru: "Absensi berhasil — Hadir/Terlambat"]
                                                        │
                                                        ▼
                                        [Notifikasi rekap ke Kepsek & TU (jadwal)]
```

### 8.3 SOP Penanganan Manipulasi Lokasi (Fake GPS)

```
[Sistem deteksi: Mock Location / Developer Options / Fake GPS]
        │
        ▼
[Absensi DITOLAK otomatis]
        │
        ▼
[Pesan ke guru: "Manipulasi lokasi terdeteksi. Hubungi Admin TU."]
        │
        ▼
[Log keamanan tercatat: guru ID, waktu, jenis manipulasi]
        │
        ▼
[Notifikasi ke Admin TU & Kepala Sekolah]
        │
        ▼
[Admin review log keamanan]
        │
        ├──[False positive]──► Admin override status absen + catatan
        │
        └──[Manipulasi terkonfirmasi]
                │
                ▼
        [Teguran/sanksi sesuai aturan sekolah]
                │
                ▼
        [Jika berulang 3× → akun dikunci sementara, wajib klarifikasi Kepsek]
```

### 8.4 SOP Pengajuan Izin/Sakit/Dinas Luar

```
[Guru tidak dapat hadir / harus dinas luar]
        │
        ▼
[Guru login portal guru → menu "Pengajuan Izin"]
        │
        ▼
[Isi form: tipe, tanggal, alasan, upload surat bukti]
        │
        ▼
[Submit → status "Pending"]
        │
        ▼
[Admin terima notifikasi → review]
        │
        ├──[Approve]──► Status absen tanggal terkait = sesuai tipe izin
        │                 └──► Notifikasi ke guru: "Pengajuan disetujui"
        │
        └──[Reject + alasan]──► Notifikasi ke guru: "Pengajuan ditolak — {alasan}"
                                  └──► Guru wajib absen normal atau ajukan ulang
```

### 8.5 SOP Override Absen oleh Admin

```
[Ada guru status absen perlu dikoreksi (dinas mendadak, sistem error, dll)]
        │
        ▼
[Admin login panel admin → cari guru → tanggal terkait]
        │
        ▼
[Klik "Override Status"]
        │
        ▼
[Pilih status baru + wajib isi catatan (min. 10 karakter)]
        │
        ▼
[Konfirmasi → Simpan]
        │
        ▼
[Audit trail tercatat: admin, waktu, status lama→baru, catatan]
        │
        ▼
[Notifikasi ke guru: "Status absen Anda diperbarui oleh Admin"]
```

---

# BAGIAN III — BUKU PANDUAN PENGGUNA (USER MANUAL)

---

## 9A. PANDUAN UNTUK GURU

### A.1 Informasi Link Akses

| Portal | URL |
|---|---|
| Portal Guru | `https://smpkartika14-1.sch.id` |

Catatan: Portal guru dapat diakses dari perangkat apa pun (HP, tablet, laptop) dan dari jaringan mana pun (seluler, Wi-Fi rumah, Wi-Fi sekolah). Tidak ada batasan lokasi untuk login dan melihat riwayat. Batasan lokasi 300 meter hanya berlaku untuk scan wajah absensi harian.

---

### A.2 Login Pertama Kali

**Langkah-langkah:**

1. Buka browser (Chrome/Safari) di HP atau laptop.
2. Kunjungi `https://smpkartika14-1.sch.id`.
3. Pada halaman login, masukkan:
   - **NIP** atau **Email** (sesuai data yang diberikan Admin TU).
   - **PIN Awal** 6 digit (diberikan Admin TU saat pendaftaran).
4. Klik **"Masuk"**.
5. Pada login pertama, sistem akan meminta Anda **mengganti PIN**:
   - Masukkan PIN lama.
   - Masukkan PIN baru 6 digit (hindari 123456, tanggal lahir, atau angka berulang).
   - Konfirmasi PIN baru.
6. Klik **"Simpan PIN Baru"**.
7. Anda akan masuk ke beranda portal guru.

**Jika lupa PIN:** Hubungi Admin TU untuk reset PIN. Admin akan mengirim PIN baru sementara via WhatsApp/Email. Anda wajib mengganti PIN tersebut saat login berikutnya.

---

### A.3 Mendaftarkan Wajah Pertama Kali (Face Enrollment)

Pendaftaran wajah dapat dilakukan dari mana saja (rumah, kafe, mana pun) — tidak perlu di sekolah.

**Langkah-langkah:**

1. Login ke portal guru.
2. Klik menu **"Daftar Wajah"** di beranda atau sidebar.
3. Sistem akan meminta izin akses kamera. Klik **"Izinkan"**.
4. Posisikan wajah Anda di dalam area oval yang ditampilkan di layar:
   - Hadap lurus ke kamera.
   - Pastikan wajah terkena pencahayaan yang cukup (tidak gelap, tidak silau).
   - Lepas masker, kacamata hitam, atau penutup wajah.
5. Ikuti instruksi sistem:
   - **"Hadap depan"** → tunggu capture.
   - **"Toleh sedikit ke kiri"** → tunggu capture.
   - **"Toleh sedikit ke kanan"** → tunggu capture.
   - **"Kedipkan mata 2 kali"** (liveness check).
6. Sistem akan menampilkan pesan **"Pendaftaran wajah berhasil. Menunggu validasi Admin."**
7. Status wajah Anda sekarang **"Pending"**. Anda belum dapat absen sampai Admin menyetujui.
8. Anda akan menerima notifikasi (WhatsApp/Email) saat Admin menyetujui atau menolak pendaftaran wajah Anda.
   - Jika **disetujui**: status berubah "Active", Anda dapat absen.
   - Jika **ditolak**: Anda akan diminta mendaftar ulang dengan alasan yang diberikan Admin.

**Tips Pendaftaran Wajah Berkualitas:**
- Lakukan di tempat dengan cahaya alami yang merata.
- Hindari latar belakang ramai/berpola.
- Pastikan hanya wajah Anda yang terlihat di kamera.
- Jangan gunakan foto cetak atau video — sistem akan menolak.

---

### A.4 Melakukan Scan Wajah Harian (Datang & Pulang)

**SYARAT WAJIB sebelum scan:**
- Anda berada di dalam radius **300 meter dari SMP Kartika XIV-1 Banda Aceh** (Jl. Nyak Adam Kamil II, Peuniti, Kec. Baiturrahman, Kota Banda Aceh).
- GPS perangkat **AKTIF** dengan mode **"Akurasi Tinggi" (High Accuracy)**.
- **Developer Options** perangkat **DIMATIKAN** (nonaktifkan USB Debugging).
- **Tidak menggunakan** aplikasi Fake GPS atau pemalsu lokasi apa pun.
- Waktu scan berada dalam jam kerja hari ini (Senin–Sabtu, sesuai jadwal yang ditetapkan Admin).

**Langkah-langkah:**

1. Login ke portal guru.
2. Klik tombol **"Absen Sekarang"** di beranda.
3. Sistem akan:
   - Mendeteksi lokasi Anda (mungkin butuh beberapa detik).
   - Menampilkan peta mini dengan marker sekolah, lingkaran radius 300 m, dan posisi Anda.
4. **Jika Anda di dalam radius 300 m:**
   - Tombol **"Scan Wajah"** aktif (berwarna hijau).
   - Klik tombol tersebut.
5. **Jika Anda di luar radius 300 m:**
   - Tombol **"Scan Wajah"** terkunci (berwarna abu-abu).
   - Muncul pesan: "Anda berada di luar area sekolah (jarak X meter). Absensi hanya dapat dilakukan di dalam radius 300 meter SMP Kartika XIV-1 Banda Aceh."
   - Jika Anda memang sedang dinas luar, gunakan menu **Pengajuan Izin** (lihat A.5).
6. Saat kamera aktif:
   - Posisikan wajah di area oval.
   - Ikuti instruksi liveness (misal: "Kedipkan mata", "Tersenyum").
   - Tunggu hingga sistem memproses (di bawah 2 detik).
7. Hasil scan:
   - **Berhasil**: Muncul konfirmasi "Absensi Berhasil — Hadir/Terlambat (X menit)" + foto bukti thumbnail.
   - **Gagal lokasi**: Ulangi setelah memastikan GPS aktif & berada di area sekolah.
   - **Gagal liveness**: Pastikan wajah asli, bukan foto/video. Ulangi.
   - **Gagal mock location**: Sistem mendeteksi manipulasi lokasi. Hubungi Admin TU.
8. Untuk absen **pulang**, ulangi langkah yang sama pada jam pulang hari itu.

**Jika internet sekolah terputus saat scan:**
- Sistem akan menyimpan data scan di perangkat Anda (status "Tersimpan offline").
- Saat internet kembali, data otomatis tersinkronisasi ke server.
- Anda tetap mendapat konfirmasi absen berhasil.

---

### A.5 Mengajukan Izin/Sakit/Dinas Luar

Digunakan jika Anda tidak dapat hadir atau harus bertugas di luar radius 300 meter sekolah.

**Langkah-langkah:**

1. Login ke portal guru.
2. Klik menu **"Pengajuan Izin"**.
3. Klik **"+ Ajukan Izin Baru"**.
4. Isi form:
   - **Tipe Izin**: pilih Izin / Sakit / Dinas Luar / Cuti.
   - **Tanggal Mulai**: pilih tanggal.
   - **Tanggal Selesai**: pilih tanggal.
   - **Alasan**: tulis alasan dengan jelas.
   - **Surat Bukiti**: upload file (PDF/JPG/PNG). Wajib untuk Sakit dan Dinas Luar (surat dokter / surat tugas). Ukuran maksimum 2 MB, sistem akan mengompres otomatis.
   - Untuk **Dinas Luar**, sistem akan mengambil koordinat lokasi Anda saat itu (opsional).
5. Klik **"Kirim Pengajuan"**.
6. Status pengajuan: **"Pending"** — menunggu persetujuan Admin.
7. Anda akan menerima notifikasi (WhatsApp/Email) saat Admin menyetujui atau menolak.
   - **Disetujui**: status absensi pada tanggal terkait otomatis berubah sesuai tipe izin. Anda tidak perlu scan wajah pada tanggal tersebut.
   - **Ditolak**: Anda akan menerima alasan penolakan. Anda wajib absen normal atau mengajukan ulang.

---

### A.6 Melihat Riwayat Absensi Mandiri

1. Login ke portal guru.
2. Klik menu **"Riwayat Absensi"**.
3. Anda melihat:
   - **Tabel riwayat harian**: tanggal, jam datang, jam pulang, status (Hadir/Terlambat/Izin/Sakit/Alpha), foto bukti (thumbnail kecil).
   - **Filter**: pilih bulan, atau filter berdasarkan status.
   - **Statistik bulan berjalan**: total hadir, total terlambat, total izin, total alpha.
4. Untuk mengunduh riwayat pribadi sebagai PDF, klik **"Unduh Riwayat (PDF)"**. File berisi riwayat absensi Anda untuk bulan yang dipilih (tanpa kop sekolah — untuk arsip pribadi).

---

## 9B. PANDUAN UNTUK ADMIN/PENGELOLA

### B.1 Informasi Link Akses

| Portal | URL |
|---|---|
| Portal Admin | `https://admin.smpkartika14-1.sch.id` |

**Catatan Keamanan:**
- Portal admin hanya dapat diakses dari **jaringan internal sekolah** (Wi-Fi/LAN kantor TU, jaringan Kepala Sekolah) karena dilindungi IP Whitelisting.
- Jika Anda perlu akses dari luar sekolah (dinas luar, WFH), hubungi Super Admin untuk mendapatkan token akses sementara (berlaku 1 jam).
- Portal admin tidak muncul di hasil pencarian Google.
- Selalu logout setelah selesai. Sesi akan otomatis logout setelah 15 menit tidak aktif.

---

### B.2 Login Admin

**Langkah-langkah:**

1. Pastikan perangkat Anda terhubung ke **jaringan internal sekolah** (Wi-Fi/LAN TU).
2. Buka browser (Chrome/Safari) dan kunjungi `https://admin.smpkartika14-1.sch.id`.
3. Masukkan:
   - **Username** (diberikan Super Admin).
   - **Password** (minimal 12 karakter, kombinasi huruf besar, huruf kecil, angka, simbol).
4. Jika 2FA aktif, masukkan kode dari aplikasi Google Authenticator.
5. Klik **"Masuk"**.
6. Anda masuk ke dashboard admin.

**Kebijakan Password:**
- Password wajib diganti setiap 90 hari.
- Tidak boleh sama dengan 5 password terakhir.
- Jika 5 kali gagal login, akun terkunci 30 menit + notifikasi ke Kepala Sekolah.

---

### B.3 Memvalidasi (Approve/Reject) Pendaftaran Wajah Guru

**Langkah-langkah:**

1. Login ke panel admin.
2. Pada dashboard, lihat notifikasi **"Pendaftaran Wajah Menunggu Validasi"** (jumlah guru pending). Klik notifikasi tersebut, atau buka menu **"Persetujuan Wajah"** di sidebar.
3. Anda melihat daftar guru dengan status "Pending", masing-masing menampilkan:
   - **Foto wajah hasil enrollment** (foto yang baru didaftarkan guru).
   - **Foto profil resmi** (foto referensi dari data Dapodik / foto yang Anda upload saat pendaftaran guru).
   - **Data identitas**: NIP, nama, jabatan.
4. **Bandingkan kedua foto** dengan cermat:
   - Apakah wajah pada foto enrollment adalah wajah guru yang bersangkutan?
   - Apakah ciri-ciri (bentuk wajah, gaya rambut, atribut) sesuai?
5. Jika **sesuai**:
   - Klik tombol **"Approve"**.
   - Status wajah guru berubah menjadi **"Active"**.
   - Guru menerima notifikasi "Pendaftaran wajah disetujui. Anda dapat melakukan absensi."
6. Jika **tidak sesuai** (dugaan pendaftaran wajah orang lain):
   - Klik tombol **"Reject"**.
   - Wajib isi **alasan penolakan** (contoh: "Foto wajah tidak sesuai dengan data guru. Silakan daftar ulang dengan wajah Anda sendiri.").
   - Status wajah berubah **"Rejected"**.
   - Guru menerima notifikasi + alasan, dan diminta mendaftar ulang.
7. Setiap aksi approve/reject tercatat di **Audit Trail** (siapa admin, kapan, guru siapa, aksi).

---

### B.4 Mengedit Jam Masuk/Pulang Harian (Senin–Sabtu)

**Langkah-langkah:**

1. Login ke panel admin.
2. Buka menu **"Pengaturan Jadwal"** di sidebar.
3. Anda melihat tabel jadwal mingguan:

   | Hari | Jam Masuk | Toleransi | Jam Pulang | Aktif |
   |---|---|---|---|---|
   | Senin | 07.15 | 15 mnt | 15.30 | ✓ |
   | Selasa | 07.15 | 15 mnt | 15.30 | ✓ |
   | ... | ... | ... | ... | ... |
   | Sabtu | 07.30 | 15 mnt | 12.00 | ✓ |

4. Klik pada sel yang ingin diubah (jam masuk/pulang/toleransi) → gunakan time picker.
5. Untuk menonaktifkan absensi pada hari tertentu (misal hari libur mendadak), klik toggle **"Aktif"**.
6. Untuk membuat **jadwal khusus** (misal Ramadhan):
   - Klik **"+ Jadwal Khusus"**.
   - Beri nama (contoh: "Jadwal Ramadhan 2026").
   - Atur jam masuk/pulang per hari.
   - Tentukan rentang tanggal efektif (tanggal mulai–selesai).
   - Klik **"Simpan"**. Sistem otomatis beralih ke jadwal khusus saat tanggal efektif tiba.
7. Klik **"Simpan Perubahan"**. Sistem menampilkan preview perubahan.
8. Konfirmasi dengan klik **"Ya, Simpan"**.
9. Perubahan tercatat di Audit Trail.

---

### B.5 Mengelola Data Guru (Tambah, Edit, Hapus, Reset Password)

#### B.5.1 Menambah Guru Manual (Satu per Satu)

1. Buka menu **"Data Guru"**.
2. Klik **"+ Tambah Guru"**.
3. Isi form:
   - NIP, Nama Lengkap, Email, No. HP, Jabatan, Status Kepegawaian (PNS/Honorer), PIN Awal (6 digit), upload Foto Profil.
4. Klik **"Simpan"**.
5. Sistem otomatis mengirim kredensial (NIP/Email + PIN awal) ke guru via WhatsApp/Email.

#### B.5.2 Menambah Guru Massal via Excel

1. Buka menu **"Data Guru"**.
2. Klik **"Import Massal"**.
3. Klik **"Unduh Template Excel"** untuk mendapatkan format.
4. Isi template sesuai kolom: NIP, Nama, Email, No. HP, Jabatan, Status Kepegawaian, PIN Awal.
5. Upload file Excel yang sudah diisi.
6. Sistem melakukan **validasi & preview**:
   - Cek NIP duplikat.
   - Cek format email.
   - Tampilkan ringkasan: X guru akan ditambah, Y error.
7. Klik **"Konfirmasi Import"**.
8. Sistem mengirim kredensial ke semua guru baru via WhatsApp/Email.

#### B.5.3 Edit Profil Guru

1. Buka **"Data Guru"** → cari guru (kotak pencarian / filter).
2. Klik nama guru → halaman detail.
3. Klik **"Edit"**.
4. Ubah field yang diperlukan (NIP tidak dapat diubah setelah dibuat).
5. Klik **"Simpan"**. Perubahan tercatat di Audit Trail.

#### B.5.4 Hapus/Nonaktifkan Guru

1. Buka **"Data Guru"** → detail guru.
2. Pilih:
   - **"Nonaktifkan"** → status guru "Tidak Aktif", data tetap tersimpan (soft delete). Guru tidak dapat login.
   - **"Hapus Permanen"** (hanya Super Admin) → konfirmasi ganda + alasan wajib. Data dihapus permanen.
3. Aksi tercatat di Audit Trail.

#### B.5.5 Reset Password/PIN Guru

1. Buka **"Data Guru"** → detail guru.
2. Pada bagian **"Kredensial"**:
   - Klik **"Lihat Username"** untuk melihat username guru.
   - Klik **"Reset PIN"** → sistem generate PIN baru 6 digit acak.
   - PIN baru ditampilkan **sekali** di layar.
   - Klik **"Kirim ke Guru"** → PIN dikirim via WhatsApp/Email.
3. Guru wajib mengganti PIN saat login berikutnya.
4. Aksi reset tercatat di Audit Trail.

#### B.5.6 Reset Face ID Guru

1. Buka **"Data Guru"** → detail guru.
2. Pada bagian **"Data Wajah"**, klik **"Reset Face ID"**.
3. Konfirmasi (centang "Saya yakin ingin mereset data wajah guru ini").
4. Embedding wajah guru dihapus. Status wajah = "Not Enrolled".
5. Sistem mengirim notifikasi ke guru: "Data wajah Anda telah direset. Silakan lakukan pendaftaran wajah ulang melalui portal guru."
6. Aksi tercatat di Audit Trail.

---

### B.6 Mengatur Titik Koordinat Sekolah, Kop Surat, Logo, & Tanda Tangan Kepala Sekolah

#### B.6.1 Mengatur Titik Koordinat Sekolah (Google Maps)

1. Buka menu **"Pengaturan Lokasi"**.
2. Anda melihat peta Google Maps interaktif dengan marker di lokasi sekolah saat ini.
3. Untuk menyesuaikan:
   - **Seret marker** (pin merah) ke titik pusat sekolah yang akurat, atau
   - **Input manual** Latitude dan Longitude di kolom yang disediakan, atau
   - Klik **"Gunakan Lokasi Saya"** (jika Anda sedang berada di lokasi sekolah).
4. Sistem menampilkan lingkaran radius 300 meter di sekitar marker.
5. Radius default **300 meter** (terkunci). Jika perlu mengubah, klik **"Ubah Radius"** + isi alasan + konfirmasi ganda.
6. Klik **"Simpan Koordinat"**.
7. Perubahan tercatat di Audit Trail (koordinat lama → baru).

#### B.6.2 Mengatur Kop Surat & Logo Sekolah

1. Buka menu **"Pengaturan Laporan"** → tab **"Kop & Logo"**.
2. Upload **Logo Sekolah**:
   - Klik **"Pilih File"** → pilih gambar (PNG/JPG transparan, maks 1 MB).
   - Sistem auto-resize ke 200×200 px.
   - Preview logo muncul.
3. Isi teks Kop Surat:
   - **Nama Sekolah** (contoh: "SMP KARTIKA XIV-1 BANDA ACEH").
   - **Alamat** (Jl. Nyak Adam Kamil II, Peuniti, Kec. Baiturrahman, Kota Banda Aceh).
   - **Nomor Telepon / Email / Fax**.
4. Klik **"Simpan"**.
5. Klik **"Preview Laporan"** untuk melihat tampilan kop di laporan cetak.
6. Perubahan tercatat di Audit Trail.

#### B.6.3 Mengatur Tanda Tangan Kepala Sekolah & Stempel

1. Buka menu **"Pengaturan Laporan"** → tab **"Tanda Tangan & Stempel"**.
2. Isi:
   - **Nama Kepala Sekolah** (text input).
   - **NIP Kepala Sekolah** (text input).
3. Upload **Scan Tanda Tangan**:
   - Klik **"Pilih File"** → pilih gambar PNG transparan (maks 500 KB).
   - Sistem auto-resize.
   - Preview muncul.
4. Upload **Stempel Digital Sekolah**:
   - Klik **"Pilih File"** → pilih gambar PNG transparan (maks 500 KB).
   - Preview muncul.
5. Atur posisi (default: footer kanan laporan, di bawah tabel absensi).
6. Klik **"Simpan"**.
7. Klik **"Preview Laporan"** untuk memastikan tanda tangan & stempel tampil dengan benar.
8. Perubahan tercatat di Audit Trail.

---

### B.7 Mengecek Laporan, Override Absen, Audit Trail, & Unduh Laporan

#### B.7.1 Mengecek Laporan Harian/Bulanan

1. Buka menu **"Laporan"**.
2. Pilih tipe laporan:
   - **Harian**: pilih tanggal. Tampilkan tabel per guru (jam datang, jam pulang, status, foto bukti).
   - **Mingguan**: pilih minggu. Rekap + grafik bar.
   - **Bulanan**: pilih bulan. Matrix guru × tanggal + grafik pie + grafik line tren kehadiran.
3. Gunakan filter (per guru, per status, per jabatan) jika diperlukan.
4. Lihat grafik di dashboard: persentase kehadiran harian, mingguan, bulanan.

#### B.7.2 Override Absen Manual

1. Buka **"Laporan Harian"** → pilih tanggal.
2. Cari guru yang status absennya perlu dikoreksi.
3. Klik **"Override Status"** pada baris guru tersebut.
4. Pilih **status baru**: Hadir / Terlambat / Izin / Sakit / Dinas Luar / Alpha.
5. Wajib isi **catatan/alasan** (minimal 10 karakter, contoh: "Guru mendapat tugas dinas mendadak dari Kepsek pada tanggal X").
6. Klik **"Simpan Override"**.
7. Sistem mencatat di Audit Trail: admin, waktu, status lama → baru, catatan.
8. Sistem mengirim notifikasi ke guru: "Status absen Anda pada [tanggal] diperbarui oleh Admin menjadi [status baru]."
9. **Catatan:** Admin tidak dapat melakukan override pada absensi dirinya sendiri.

#### B.7.3 Melihat Log Riwayat Aktivitas Admin (Audit Trail)

1. Buka menu **"Audit Trail"** (hanya Super Admin & Kepala Sekolah yang dapat melihat penuh; Admin TU melihat aktivitasnya sendiri).
2. Anda melihat tabel log dengan kolom:
   - **Timestamp** (waktu aktivitas).
   - **Admin** (nama/username admin yang melakukan aksi).
   - **Aktivitas** (login, edit jadwal, approve wajah, reset PIN, override absen, hapus guru, dll).
   - **Detail** (data lama → baru, guru terkait, catatan).
   - **IP Address** & **Perangkat**.
3. Gunakan filter (per admin, per tipe aktivitas, per rentang tanggal).
4. Klik **"Export Audit Trail"** untuk mengunduh log sebagai Excel/CSV (arsip keamanan).

#### B.7.4 Mengunduh Laporan Harian/Bulanan Berstempel Digital

1. Buka **"Laporan"** → pilih harian/bulanan → pilih tanggal/bulan.
2. Klik **"Unduh PDF"** atau **"Unduh Excel"**.
3. File yang diunduh **sudah lengkap**:
   - **Kop Surat** sekolah di bagian atas.
   - **Logo Sekolah** di kop.
   - **Tabel absensi** (data guru, jam datang/pulang, status).
   - **Tanda Tangan Kepala Sekolah** + **NIP** di footer kanan.
   - **Stempel Digital Sekolah** di footer.
   - **Tanggal Cetak** otomatis.
4. File siap dicetak atau dikirim ke Kepala Sekolah / Dinas Pendidikan secara langsung — sudah legal secara administrasi.

---

# BAGIAN IV — LAMPIRAN TEKNIS

---

## LAMPIRAN A. ARSITEKTUR SISTEM (RINGKASAN)

```
┌─────────────────────────────────────────────────────────┐
│                    PENGGUNA (Guru & Admin)                │
│           Browser / PWA di HP, Tablet, Laptop             │
└────────────┬────────────────────────┬────────────────────┘
             │ HTTPS (TLS 1.2/1.3)     │
             ▼                        ▼
   ┌──────────────────┐      ┌──────────────────┐
   │  Portal Guru      │      │  Portal Admin    │
   │  (publik)         │      │  (IP Whitelist)  │
   │  smpkartika...    │      │  admin.smpkartika│
   └────────┬─────────┘      └────────┬─────────┘
            │                          │
            └──────────┬───────────────┘
                       ▼
            ┌─────────────────────┐
            │   API Gateway /     │
            │   Reverse Proxy     │
            │   (Nginx/Cloudflare)│
            └──────────┬──────────┘
                       ▼
     ┌─────────────────────────────────┐
     │        Application Server        │
     │  (Auth, Absensi, Laporan, DLL)   │
     └──────┬──────────┬──────────┬────┘
            │          │          │
            ▼          ▼          ▼
     ┌──────────┐ ┌────────┐ ┌──────────┐
     │ Database │ │ Object │ │ Face Rec │
     │ (Postgres│ │Storage │ │ Engine   │
     │ /Supabase)│ │(foto)  │ │(FaceNet/ │
     └──────────┘ └────────┘ │ ArcFace) │
                             └──────────┘
                       │
            ┌──────────┴──────────┐
            ▼                     ▼
     ┌────────────┐      ┌────────────┐
     │ WhatsApp   │      │ Email SMTP │
     │ Gateway    │      │ (SendGrid) │
     └────────────┘      └────────────┘
```

---

## LAMPIRAN B. DAFTAR ENTITAS DATA (SKEMA DATABASE RINGKAS)

| Tabel | Deskripsi | Field Utama |
|---|---|---|
| `admin` | Data admin | id, username, password_hash, role, 2fa_secret, last_login |
| `teacher` | Data guru | id, nip, name, email, phone, jabatan, status_kepegawaian, pin_hash, face_status, face_embedding, photo_url, is_active |
| `face_enrollment` | Riwayat pendaftaran wajah | id, teacher_id, status (pending/active/rejected), photo_ref, embedding, created_at, approved_by, approved_at |
| `attendance` | Record absensi harian | id, teacher_id, date, check_in, check_out, status, lat, lng, distance_m, photo_proof_url, is_mock, sync_status |
| `weekly_schedule` | Jadwal mingguan | id, day (mon-sat), check_in_time, check_out_time, tolerance_minutes, is_active |
| `special_schedule` | Jadwal khusus (Ramadhan dll) | id, name, start_date, end_date, schedule_json |
| `leave_request` | Pengajuan izin/sakit/dinas | id, teacher_id, type, start_date, end_date, reason, document_url, status, approved_by, approved_at |
| `school_setting` | Pengaturan sekolah | id, name, address, lat, lng, geofence_radius, logo_url, kop_text, principal_name, principal_nip, principal_signature_url, stamp_url |
| `admin_audit_log` | Audit trail | id, admin_id, action, target_type, target_id, old_value, new_value, note, ip, device, created_at |
| `notification_log` | Log notifikasi | id, recipient, channel (wa/email), message, status, sent_at |
| `ip_whitelist` | IP yang diizinkan akses admin | id, ip_range, label, created_by, created_at |

---

## LAMPIRAN C. DAFTAR PRIORITAS PENGEMBANGAN

| Prioritas | Modul | Catatan |
|---|---|---|
| P0 (Wajib) | Auth guru & admin, URL separation, SSL, IP whitelist | Fondasi keamanan |
| P0 | Face enrollment + approval admin | Inti pendaftaran |
| P0 | Geofencing 300 m + anti-mock location | Inti absensi |
| P0 | Liveness detection | Anti-kecurangan |
| P0 | Scan wajah < 2 detik | Performa |
| P1 | Jadwal Senin–Sabtu + toleransi | Manajemen waktu |
| P1 | Portal guru (riwayat, pengajuan izin) | Self-service |
| P1 | Dashboard admin + laporan | Pengelolaan |
| P1 | Audit trail | Akuntabilitas |
| P2 | Mode offline + sync | Ketahanan |
| P2 | Kop/logo/ttd/stempel laporan | Legalitas cetak |
| P2 | WhatsApp/Email gateway | Notifikasi |
| P3 | Payroll integration | Penggajian |
| P3 | Dapodik export | Pelaporan |
| P3 | Shifting guru honorer/piket/lembur | Skenario khusus |

---

## LAMPIRAN D. NON-FUNCTIONAL REQUIREMENTS

| Kategori | Spesifikasi |
|---|---|
| Performa | Scan wajah < 2 detik; dashboard load < 3 detik; API response < 500 ms |
| Skalabilitas | Mendukung 100+ guru (skala SMP); arsitektur horizontal scalable |
| Ketersediaan | Uptime ≥ 99.5% (downtime maks 3.6 jam/tahun) |
| Keamanan | TLS 1.2/1.3, password hashing (bcrypt/argon2), JWT, RBAC, audit trail, IP whitelist, anti-mock location, liveness detection |
| Privasi | Data wajah disimpan sebagai embedding (bukan foto mentah); kepatuhan UU PDP Indonesia |
| Kompatibilitas | Browser: Chrome, Safari, Firefox, Edge (2 versi terakhir); OS: Android 8+, iOS 12+, Windows, macOS |
| Aksesibilitas | WCAG 2.1 AA (kontras, navigasi keyboard, label form) |
| Backup | Database backup harian otomatis; retensi 30 hari; disaster recovery RTO 4 jam |
| Lokasi Server | Cloud (Supabase / regional Indonesia/Singapura) untuk latensi rendah |

---

**DOKUMEN INI SIAP DIBERIKAN KEPADA:**
1. Tim Developer Software — sebagai acuan pengembangan (SRS).
2. Pihak Sekolah (Kepala Sekolah, TU) — sebagai SOP & Panduan Pengguna resmi.

**END OF DOCUMENT**
