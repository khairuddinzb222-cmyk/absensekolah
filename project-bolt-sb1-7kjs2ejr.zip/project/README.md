# absensi-guru-smp-kartika

[![Open in Bolt](https://bolt.new/static/open-in-bolt.svg)](https://bolt.new/~/sb1-7kjs2ejr)
